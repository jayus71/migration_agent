"""Shared initial generation and exact provider-usage receipts."""
import hashlib
import json
import re

def extract(text):
    blocks = re.findall(r'```(?:python|py)?\s*\n(.*?)```', text, re.S)
    return ('\n\n'.join(blocks) if blocks else text).strip() + '\n'

def cte_candidate(response):
    translations = response.get('translation_responses', [])
    if len(translations) != 1:
        raise ValueError('Expected one native translation response')
    paths = translations[0].get('paths', [])
    edges = {edge['edge_id']: edge for path in paths
             for edge in path.get('translation_edges', [])}
    target_edges = [edge for edge in edges.values()
                    if edge.get('target_language') == 'Python'
                    and edge.get('extracted_source_code')]
    if len(target_edges) > 1:
        raise ValueError('Direct translation produced multiple candidates; selection is not declared')
    return target_edges[0]['extracted_source_code'] if target_edges else ''

def generate(request, output, *, method, group, client):
    """Archive every attempted transport, including errors, before returning."""
    if output.exists():
        raise FileExistsError('A prior attempt exists; failures are not regenerated')
    output.mkdir(parents=True)
    (output / 'request.json').write_text(json.dumps(request, indent=2) + '\n')
    record = {'method': method, 'group': group, 'status': 'started', 'transport_calls': 1,
              'real_model_calls': 1 if method == 'direct' else None,
              'usage': None, 'usage_kind': 'unavailable'}
    try:
        response = client(request)
        (output / 'response.json').write_text(json.dumps(response, indent=2) + '\n')
        if method == 'direct':
            choice = response['choices'][0]
            content = choice['message'].get('content') or ''
            code = extract(content)
            record.update(usage=response.get('usage'), finish_reason=choice.get('finish_reason'))
            record['usage_kind'] = 'provider' if record['usage'] is not None else 'unavailable'
        else:
            code = cte_candidate(response)
            if '_provider_ledger' in response:
                record.update(real_model_calls=response['_provider_ledger']['calls'],
                              usage=response['_provider_ledger']['usage'],
                              provider_ledger=response['_provider_ledger'])
                record['usage_kind'] = 'provider' if record['usage'] is not None else 'partial_provider'
        (output / 'candidate.py').write_text(code)
        record.update(status='generated' if code.strip() else 'generation_failed',
                      candidate_sha256=hashlib.sha256(code.encode()).hexdigest())
    except Exception as exc:
        record.update(status='transport_or_protocol_error', error=f'{type(exc).__name__}: {exc}')
        raise
    finally:
        (output / 'generation.json').write_text(json.dumps(record, indent=2) + '\n')
    return record
