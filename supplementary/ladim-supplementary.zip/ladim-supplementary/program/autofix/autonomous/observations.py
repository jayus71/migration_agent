"""Public measurements and acceptance for tasks without supplied diagnoses.

The evaluator owns the input JSON and the execution attestation. This module
does not turn labels, fault manifests, or diagnostic metadata into evidence.
"""

from __future__ import annotations

import math
import re
from collections.abc import Mapping
from typing import Any


SCHEMA_VERSION = "autonomous-observation-v1"
_FAULT_ID = re.compile(r"(?i)\b(?:EX|NU|GR|MX|BL|UP)[-_]\d{2}(?:[-_][AB])?\b")
_OPAQUE_CASE = re.compile(r"(?i)\bFAULT_CASE_\d+\b")
_ABSOLUTE_PATH = re.compile(r"(?<![\w.])(?:[A-Za-z]:[/\\]|/)[^\s\"'<>:,;()\[\]{}]+")
_DEFAULT_THRESHOLDS = {"loss_abs": 1e-3, "grad_norm_abs": 1e-3, "param_rel_l2": 1e-2}
_METRICS = {
    "loss_abs_diff": ("last_step_abs_loss_diff", "loss_abs"),
    "grad_norm_abs_diff": ("last_step_abs_grad_norm_diff", "grad_norm_abs"),
    "param_update_rel_l2": ("param_update_rel_l2", "param_rel_l2"),
}


def _mapping(value: Any) -> Mapping[str, Any]:
    return value if isinstance(value, Mapping) else {}


def _finite_number(value: Any, *, nonnegative: bool = False) -> float | None:
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        return None
    try:
        number = float(value)
    except (OverflowError, ValueError):
        return None
    if not math.isfinite(number) or (nonnegative and number < 0):
        return None
    return number


def sanitize_runtime_text(text: Any, path_aliases: Mapping[str, str] | None = None) -> str:
    """Keep runtime evidence while replacing evaluator paths and case IDs.

    Aliases are supplied by the task builder, never read from the report.
    Relative production paths remain useful localization evidence.
    """
    if not isinstance(text, str):
        return ""
    value = text.replace("\\", "/")
    for private_path, public_path in sorted((path_aliases or {}).items(), key=lambda item: -len(str(item[0]))):
        private = str(private_path).replace("\\", "/")
        public = str(public_path).replace("\\", "/")
        if private:
            value = value.replace(private, public)

    def replace_path(match: re.Match[str]) -> str:
        path = match.group(0)
        if "/target_library/" in path:
            return "target_library/" + path.rsplit("/target_library/", 1)[1]
        basename = path.rsplit("/", 1)[-1]
        if basename in {"source.py", "reference.py"}:
            return "source.py"
        if basename == "candidate.py":
            return "candidate.py"
        # Absolute evaluator, artifact, dependency, and historical paths are
        # excluded. The task builder may alias a useful public dependency.
        return "<runtime-path>"

    value = _ABSOLUTE_PATH.sub(replace_path, value)
    value = _FAULT_ID.sub("<case>", value)
    value = _OPAQUE_CASE.sub("<case>", value)
    return value[-8000:]


def _runtime_error(stdout: str, stderr: str) -> str:
    # Generic stdout may contain arbitrary JSON or report metadata. Only use
    # the last traceback as a fallback when a report could not be produced.
    for stream in (stderr, stdout):
        if not isinstance(stream, str):
            continue
        marker = stream.rfind("Traceback (most recent call last):")
        if marker >= 0:
            lines = stream[marker:].splitlines()
            kept = []
            for line in lines:
                if line.lstrip().startswith(("{", "[")):
                    break
                kept.append(line)
            return "\n".join(kept)
    return ""


def _runtime_diagnostics(stdout: str, stderr: str, aliases: Mapping[str, str] | None) -> dict:
    # Reports can catch an exception and exit successfully, while the target
    # runtime logged its useful dispatch frames to stderr. Preserve those
    # literal messages without treating arbitrary stdout JSON as diagnostics.
    lines = []
    for stream in (stdout, stderr):
        if not isinstance(stream, str):
            continue
        lines.extend(line for line in stream.splitlines() if re.match(
            r"^(?:ERROR|WARNING|CRITICAL):|^\[(?:ERROR|WARNING)\]|^\s*File [\"']|^\w*(?:Error|Exception):", line))
    text = "\n".join(lines)
    return {"text": sanitize_runtime_text(text, aliases), "truncated": len(text) > 8000,
            "origin": "literal runtime diagnostics; bounded tail"}


def _side_execution(raw: Any, aliases: Mapping[str, str] | None) -> dict[str, Any]:
    side = _mapping(raw)
    status = side.get("status")
    if isinstance(status, str) and status in {"ok", "OK", "passed"}:
        return {"status": "passed", "error": ""}
    if isinstance(status, str) and status in {"failed", "error", "timeout"}:
        return {"status": "failed", "error": sanitize_runtime_text(side.get("error", ""), aliases)}
    return {"status": "unavailable", "error": "Execution status was not reported."}


def _measurement(value: Any, *, available: bool, reason: str = "") -> dict[str, Any]:
    if not available:
        return {"status": "unavailable", "value": None, "reason": reason}
    if value is None:
        return {"status": "unavailable", "value": None, "reason": "Measurement was not reported."}
    number = _finite_number(value, nonnegative=True)
    if number is None:
        return {"status": "invalid", "value": None, "reason": "Measurement must be a finite, nonnegative number."}
    return {"status": "observed", "value": number, "reason": ""}


def _layer_observations(payload: Mapping[str, Any], aliases: Mapping[str, str] | None) -> list[dict[str, Any]]:
    layers = _mapping(payload.get("layer_outputs"))
    reference = _mapping(layers.get("torch"))
    target = _mapping(layers.get("target_library"))
    result = []
    for name in dict.fromkeys([*reference, *target]):
        left = _finite_number(reference.get(name))
        right = _finite_number(target.get(name))
        status = "observed" if left is not None and right is not None else "unavailable"
        difference = abs(left - right) if status == "observed" else None
        if difference is not None and not math.isfinite(difference):
            status, difference = "invalid", None
        result.append({
            "name": sanitize_runtime_text(str(name), aliases),
            "status": status,
            "reference_value": left,
            "target_value": right,
            "abs_diff": difference,
        })
    return result


def _parameter_observations(comparison: Mapping[str, Any], aliases: Mapping[str, str] | None) -> list[dict[str, Any]]:
    diagnostics = _mapping(comparison.get("parameter_update_diagnostics"))
    raw_parameters = diagnostics.get("parameters")
    if not isinstance(raw_parameters, list):
        return []
    fields = ("reference_update_norm", "candidate_update_norm", "update_diff_norm", "update_rel_l2")
    result = []
    for item in raw_parameters:
        if not isinstance(item, Mapping) or not isinstance(item.get("name"), str):
            continue
        values = {field: _finite_number(item.get(field), nonnegative=True) for field in fields}
        result.append({
            "name": sanitize_runtime_text(item["name"], aliases),
            "status": "observed" if all(value is not None for value in values.values()) else "unavailable",
            **values,
        })
    return result


def build_observation(
    payload: Mapping[str, Any],
    *,
    command_returncode: int,
    stdout: str = "",
    stderr: str = "",
    path_aliases: Mapping[str, str] | None = None,
    expected_backend: str = "mindspore",
) -> dict[str, Any]:
    """Build an allowlisted observation from a trusted paired evaluator report.

    ``expected_backend`` describes the configured task, not an attestation.
    Actual backend execution must be checked independently at acceptance.
    Training measurements require the paired report's config.mode == 'train'.
    """
    report = _mapping(payload)
    results = _mapping(report.get("results"))
    reference = _side_execution(results.get("torch"), path_aliases)
    target = _side_execution(results.get("target_library"), path_aliases)
    valid_rc = isinstance(command_returncode, int) and not isinstance(command_returncode, bool)
    command_passed = valid_rc and command_returncode == 0
    execution_complete = command_passed and reference["status"] == "passed" and target["status"] == "passed"
    training = _mapping(report.get("config")).get("mode") == "train"
    comparison = _mapping(report.get("comparison"))
    measurements = {}
    for public_name, (report_name, _) in _METRICS.items():
        available = execution_complete and (public_name == "loss_abs_diff" or training)
        reason = "Execution did not complete successfully on both sides."
        if execution_complete and not training:
            reason = "Training execution was not reported."
        measurements[public_name] = _measurement(comparison.get(report_name), available=available, reason=reason)
    command_error = ""
    if not command_passed:
        command_error = sanitize_runtime_text(_runtime_error(stdout, stderr), path_aliases)
    return {
        "schema_version": SCHEMA_VERSION,
        "expected_backend": expected_backend if expected_backend in {"mindspore", "jax", "torch"} else "unknown",
        "execution": {
            "command": {"status": "passed" if command_passed else "failed", "returncode": command_returncode if valid_rc else None, "error": command_error},
            "reference": reference,
            "target": target,
            "training_reported": training,
            "runtime_diagnostics": _runtime_diagnostics(stdout, stderr, path_aliases) if not execution_complete else {"text": "", "truncated": False},
        },
        "measurements": measurements,
        "layer_differences": _layer_observations(report, path_aliases) if execution_complete else [],
        "parameter_updates": _parameter_observations(comparison, path_aliases) if execution_complete and training else [],
    }


def evaluate_acceptance(
    observation: Mapping[str, Any],
    thresholds: Mapping[str, float] | None = None,
    *,
    require_training: bool = True,
    backend_attested: bool = False,
    source_immutable: bool = False,
) -> dict[str, Any]:
    """Accept only measured agreement and independent evaluator attestations.

    Do not populate the attestation arguments from candidate output or from an
    agent diagnosis. The caller must verify backend execution and source hash.
    """
    limits = dict(_DEFAULT_THRESHOLDS)
    if thresholds is not None:
        for name in limits:
            if name in thresholds:
                number = _finite_number(thresholds[name], nonnegative=True)
                if number is None:
                    raise ValueError(f"threshold {name} must be finite and nonnegative")
                limits[name] = number
    checks: dict[str, bool] = {
        "schema": observation.get("schema_version") == SCHEMA_VERSION,
        "backend_attested": backend_attested is True,
        "source_immutable": source_immutable is True,
    }
    execution = _mapping(observation.get("execution"))
    for side in ("command", "reference", "target"):
        checks[f"{side}_execution"] = _mapping(execution.get(side)).get("status") == "passed"
    if require_training:
        checks["training_reported"] = execution.get("training_reported") is True
    measurements = _mapping(observation.get("measurements"))
    for name, (_, threshold_name) in _METRICS.items():
        if not require_training and name != "loss_abs_diff":
            continue
        metric = _mapping(measurements.get(name))
        value = _finite_number(metric.get("value"), nonnegative=True)
        checks[name] = metric.get("status") == "observed" and value is not None and value <= limits[threshold_name]
    # If the evaluator supplied these measurements, incomplete coverage cannot
    # be hidden by a passing aggregate. Empty lists mean telemetry was optional.
    for name in ("layer_differences", "parameter_updates"):
        if name == "parameter_updates" and not require_training:
            continue
        items = observation.get(name)
        checks[f"{name}_coverage"] = isinstance(items, list) and all(
            isinstance(item, Mapping) and item.get("status") == "observed" for item in items
        )
        difference_key = "abs_diff" if name == "layer_differences" else "update_rel_l2"
        threshold = limits["loss_abs" if name == "layer_differences" else "param_rel_l2"]
        checks[f"{name}_agreement"] = isinstance(items, list) and all(
            isinstance(item, Mapping)
            and (value := _finite_number(item.get(difference_key), nonnegative=True)) is not None
            and value <= threshold
            for item in items
        )
    reasons = [name for name, passed in checks.items() if not passed]
    return {"accepted": not reasons, "reasons": reasons, "checks": checks, "thresholds": limits}
