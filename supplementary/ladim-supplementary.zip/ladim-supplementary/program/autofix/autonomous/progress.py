"""Read live audit state without modifying an experiment or calling a model."""
import argparse
import json
from pathlib import Path


def inspect(run: Path) -> dict:
    manifest = json.loads((run / "manifest.json").read_text())
    rows = []
    for result_path in sorted((run / "conditions").glob("task_*/*/result.json")):
        result = json.loads(result_path.read_text())
        session_path = result_path.parent / "evidence/agent/session.json"
        session = json.loads(session_path.read_text()) if session_path.exists() else {}
        usage = result.get("budget", {}).get("usage", {}) if result.get("status") != "running" else session.get("usage", {})
        rows.append({"task": result["task"], "method": result["method"], "status": result["status"],
            "accepted": result.get("accepted"), "attempts": len(result.get("attempts", [])),
            "calls": result.get("budget", {}).get("calls", session.get("calls", 0)),
            "prompt_tokens": usage.get("prompt_tokens", 0), "completion_tokens": usage.get("completion_tokens", 0),
            "unknown_usage_calls": usage.get("unknown_usage_calls", 0), "actual_models": usage.get("actual_models", []),
            "last_stage": result.get("attempts", [{}])[-1].get("stage", {}).get("status") if result.get("attempts") else None,
            "error": result.get("error")})
    return {"run": str(run), "planned": len(manifest["tasks"]) * len(manifest["methods"]),
            "started": len(rows), "terminal": sum(r["status"] != "running" for r in rows),
            "conditions": rows}


def compact(report: dict) -> dict:
    groups = {}
    for row in report["conditions"]:
        group = groups.setdefault(row["method"], {"started": 0, "completed": 0, "running": 0,
            "accepted": 0, "errors": 0, "calls": 0, "prompt_tokens": 0, "completion_tokens": 0})
        group["started"] += 1
        group["completed"] += row["status"] == "completed"
        group["running"] += row["status"] == "running"
        group["accepted"] += row["status"] == "completed" and row["accepted"] is True
        group["errors"] += row["status"] == "infrastructure_error"
        for key in ("calls", "prompt_tokens", "completion_tokens"):
            group[key] += row[key]
    return {key: value for key, value in report.items() if key != "conditions"} | {"methods": groups}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("run", type=Path)
    parser.add_argument("--compact", action="store_true")
    args = parser.parse_args()
    report = inspect(args.run)
    print(json.dumps(compact(report) if args.compact else report, ensure_ascii=False, indent=2))
