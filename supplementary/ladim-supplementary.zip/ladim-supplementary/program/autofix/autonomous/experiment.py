"""Blinded natural migration evaluation; no fault registry or oracle diagnosis."""
from __future__ import annotations

import argparse
import os
from dataclasses import asdict
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import traceback

from autofix.autonomous.evaluation import Evaluator, digest, dump, snapshot

METHODS = ("autonomous_layered", "swe_style_shared_tools", "matchfix_shared_tools", "direct_shared_tools")
SUPPORTED_METHODS = METHODS + ("swe_native_isolated", "autonomous_layered_native", "matchfix_full_orchestration", "autonomous_category_ablation")
NATIVE_EPISODES = ("swe_native_isolated", "matchfix_full_orchestration")


def evaluator_for(run, task, workspace, evidence, python, manifest):
    raise RuntimeError("Inject UnifiedEvaluator or the evaluator for your supplied task.")


def prepare(*args, **kwargs):
    raise RuntimeError("Benchmark preparation is excluded from this data-free review package.")


def workspace_for(run: Path, task: str, method: str) -> tuple[Path, Path]:
    condition = run / "conditions" / task / method
    workspace = condition / "workspace"
    if workspace.exists():
        raise RuntimeError("Refusing to overwrite an existing condition")
    shutil.copytree(run / "private_inputs" / task, workspace)
    (workspace / "scratch_tests").mkdir()
    return workspace, condition / "evidence"


def preflight(run: Path, python: Path) -> list[dict]:
    manifest = json.loads((run / "manifest.json").read_text())
    results = []
    for row in manifest["tasks"]:
        workspace, evidence = workspace_for(run, row["anonymous_id"], "preflight")
        evaluator = evaluator_for(run, row["anonymous_id"], workspace, evidence, python, manifest)
        result = evaluator.paired()
        if result["accepted"]:
            confirmation = evaluator.confirm()
            result["confirmation"] = confirmation
            result["accepted"] = all(x["accepted"] for x in confirmation)
        results.append({"task": row["anonymous_id"], "original_id": row["original_id"], **result})
        dump(run / "preflight.json", results)
        print(json.dumps({"event": "preflight", "task": row["anonymous_id"], "accepted": result["accepted"],
                          "execution": result["observation"].get("execution"),
                          "measurements": result["observation"].get("measurements"),
                          "backend": result["observation"].get("target_backend_observed")}), flush=True)
    return results


def run_condition(run: Path, task: str, method: str, python: Path) -> dict:
    from autofix.autonomous.agent import AgentConfig, AutonomousAgent
    from autofix.autonomous.tools import WorkspaceTools
    manifest = json.loads((run / "manifest.json").read_text())
    workspace, evidence = workspace_for(run, task, method)
    if method not in SUPPORTED_METHODS:
        raise ValueError("Unknown method: " + method)
    if method in ("matchfix_shared_tools", "matchfix_full_orchestration") and not (workspace / "source.py").exists():
        result = {"task": task, "method": method, "status": "unsupported", "accepted": None,
                  "reason": "MatchFix requires a genuine source/target program pair; none is supplied by this benchmark."}
        dump(workspace.parent / "result.json", result)
        return result
    evaluator = evaluator_for(run, task, workspace, evidence, python, manifest)
    optional_config = {key: manifest[key] for key in (
        "thinking_mode", "reasoning_effort", "max_context_chars", "diagnosis_calls_per_stage",
        "repair_calls_per_stage") if key in manifest}
    config = AgentConfig(method={"autonomous_layered": "layered", "autonomous_layered_native": "layered",
                                 "autonomous_category_ablation": "layered",
                                 "direct_shared_tools": "direct"}.get(method, "single"),
                         memory_policy=manifest.get("memory_policy", {}).get(method,
                             "evidence" if method == "autonomous_layered" else "native"),
                         workflow_policy=manifest.get("workflow_policy", {}).get(method,
                             "progress_loop" if method.startswith("autonomous_") else "standard"),
                         diagnosis_policy=manifest.get("diagnosis_policy", {}).get(method, "evidence"),
                         task_kind=manifest.get("task_kind", "framework_migration"),
                         model=manifest["model"], max_calls=manifest["max_calls"],
                         max_output_tokens=manifest["max_output_tokens"], max_seconds=manifest["max_seconds"],
                         per_call_output_tokens=manifest["per_call_output_tokens"], **optional_config)
    agent = AutonomousAgent(WorkspaceTools(workspace, run_test=evaluator.tool,
        validate_syntax=manifest.get("syntax_guard", {}).get(method, method.startswith("autonomous_"))), evidence / "agent", config=config)
    adapter = None
    if method == "matchfix_shared_tools":
        from autofix.autonomous.baselines import MatchFixSharedTools
        adapter = MatchFixSharedTools(agent,
            upstream_root=Path(os.environ["LADIM_MATCHFIX_ROOT"]),
            python=os.environ["LADIM_MATCHFIX_PYTHON"])
    elif method == "matchfix_full_orchestration":
        from autofix.autonomous.baselines import MatchFixFullOrchestration
        adapter = MatchFixFullOrchestration(agent,
            upstream_root=Path(os.environ["LADIM_MATCHFIX_ROOT"]),
            python=os.environ["LADIM_MATCHFIX_PYTHON"])
    elif method == "swe_style_shared_tools":
        from autofix.autonomous.baselines import SWEStyleSharedTools
        adapter = SWEStyleSharedTools(agent)
    elif method == "swe_native_isolated":
        from autofix.autonomous.swe_upstream import SWEAgentNative
        adapter = SWEAgentNative(agent,
            upstream_root=os.environ["LADIM_SWE_ROOT"],
            python=os.environ["LADIM_SWE_PYTHON"],
            target_python=python,
            vendor=os.environ["LADIM_SWE_VENDOR"])
    started = time.monotonic()
    result = {"task": task, "method": method, "status": "running", "attempts": [], "accepted": False}
    dump(workspace.parent / "result.json", result)
    try:
        initial = evaluator.paired()
        result["initial"] = initial
        initial_hashes = snapshot(workspace, evidence / "initial_code")
        diagnosis = adapter.initialize(initial["observation"]) if adapter else agent.diagnose(initial["observation"])
        result["initial_diagnosis"] = asdict(diagnosis) if hasattr(diagnosis, "__dataclass_fields__") else diagnosis
        if result["initial_diagnosis"].get("status") in ("api_error", "infrastructure_error", "error"):
            raise RuntimeError("Diagnostic infrastructure failed: " + str(result["initial_diagnosis"]))
        # Classification and localization are recorded before any production edit.
        after_diagnosis = snapshot(workspace, evidence / "after_diagnosis")
        if initial_hashes != after_diagnosis:
            raise RuntimeError("Diagnostic phase modified production code")
        current = evaluator.paired()
        if current["accepted"]:
            checks = evaluator.confirm()
            result["confirmation"] = checks
            result["accepted"] = all(x["accepted"] for x in checks)
            if not result["accepted"]:
                current = next(x for x in checks if not x["accepted"])
        result["initially_accepted"] = result["accepted"]
        for attempt in range(1, int(manifest.get("max_repair_attempts", manifest.get("repair_attempts", 4))) + 1):
            # Native SWE investigates within its own first episode, including
            # initially healthy tasks. Its initialize only starts the runtime.
            if result["accepted"] and not (method in NATIVE_EPISODES and attempt == 1):
                break
            before = snapshot(workspace, evidence / f"before_attempt_{attempt}")
            stage = adapter.repair(current["observation"], attempt=attempt) if adapter else agent.repair(current["observation"], attempt=attempt)
            stage_data = asdict(stage) if hasattr(stage, "__dataclass_fields__") else stage
            current = evaluator.paired()
            accepted = current["accepted"]
            confirmation = evaluator.confirm() if accepted else []
            if confirmation:
                accepted = all(x["accepted"] for x in confirmation)
                if not accepted:
                    current = next(x for x in confirmation if not x["accepted"])
            after = snapshot(workspace, evidence / f"after_attempt_{attempt}")
            record = {"attempt": attempt, "stage": stage_data, "evaluation": current,
                      "confirmation": confirmation, "accepted": accepted,
                      "changed_files": sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))}
            result["attempts"].append(record)
            result["accepted"] = accepted
            dump(workspace.parent / "result.json", result)
            print(json.dumps({"event": "attempt", "task": task, "method": method, "attempt": attempt,
                              "accepted": accepted, "stage_status": stage_data.get("status")}), flush=True)
            if stage_data.get("status") in ("api_error", "infrastructure_error", "error"):
                result["infrastructure_error"] = stage_data["status"]
            if stage_data.get("status") in ("budget_exhausted", "api_error", "infrastructure_error", "error", "call_budget_exhausted", "output_budget_exhausted", "time_budget_exhausted", "context_budget_exhausted"):
                break
        result["final"] = current
        result["status"] = "infrastructure_error" if result.get("infrastructure_error") else "completed"
    except Exception as exc:
        result["status"] = "infrastructure_error"
        result["error"] = f"{type(exc).__name__}: {exc}"
        result["traceback"] = traceback.format_exc()
    finally:
        if method in NATIVE_EPISODES and adapter:
            result["initial_diagnosis"] = {"status": "native_trajectory",
                "first_production_edit": adapter.first_edit,
                "evidence_directory": str(evidence / "agent"),
                "assessment": "Use the recorded native history before first production edit; if no edit, use the submitted trajectory."}
        if adapter and hasattr(adapter, "close"):
            try:
                adapter.close()
            except Exception as exc:
                result["cleanup_error"] = f"{type(exc).__name__}: {exc}"
                result["status"] = "infrastructure_error"
        result["wall_time_sec"] = time.monotonic() - started
        result["budget"] = {"calls": agent.calls, "usage": agent.usage()}
        try:
            snapshot(workspace, evidence / "final_code")
        except Exception as exc:
            result["status"] = "infrastructure_error"
            result["accepted"] = False
            result["snapshot_error"] = f"{type(exc).__name__}: {exc}"
        dump(workspace.parent / "result.json", result)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=("prepare", "preflight", "run"))
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--archive-repo", type=Path)
    parser.add_argument("--python", type=Path, default=Path(sys.executable))
    parser.add_argument("--task")
    parser.add_argument("--method", choices=SUPPORTED_METHODS)
    args = parser.parse_args()
    if args.command == "prepare":
        prepare(args.archive_repo, args.run)
    elif args.command == "preflight":
        preflight(args.run, args.python)
    else:
        result = run_condition(args.run, args.task, args.method, args.python)
        print(json.dumps({"event": "finished", "task": args.task, "method": args.method,
                          "status": result["status"], "accepted": result["accepted"], "error": result.get("error")}), flush=True)


if __name__ == "__main__":
    main()
