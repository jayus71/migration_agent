"""Common execution and acceptance for anonymous migration workspaces."""
from __future__ import annotations

import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import stat
from typing import Any

from autofix.autonomous.observations import build_observation, evaluate_acceptance
from autofix.autonomous.sandbox import run_isolated


def dump(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def source_hashes(workspace: Path) -> dict[str, str]:
    return {name: digest(workspace / name) for name in ("source.py", "task.json")}


def backend_attested(report):
    raise NotImplementedError("Use the selected native evaluator's backend checks.")


class Evaluator:
    def __init__(self, workspace: Path, evidence: Path, python: Path):
        self.workspace, self.evidence, self.python = workspace.resolve(), evidence.resolve(), python
        self.params = json.loads((workspace / "task.json").read_text())
        self.immutable = source_hashes(workspace)
        self.calls = 0
        self.last_result: dict = {}

    def paired(self, *, seed=None, timeout=180):
        raise NotImplementedError("Use UnifiedEvaluator or supply a task-specific evaluator.")

    def tool(self, request: dict) -> dict:
        test = request["test"]
        if test in ("paired", "public"):
            return self.paired(timeout=min(180, float(request.get("timeout_seconds", 180))))["observation"]
        file = (self.workspace / test).resolve()
        if not file.is_relative_to(self.workspace / "scratch_tests") or file.suffix != ".py":
            raise ValueError("Only scratch_tests Python scripts may execute")
        result = run_isolated(self.workspace, self.python, file,
                              timeout=min(120, float(request.get("timeout_seconds", 120))))
        self.calls += 1
        dump(self.evidence / f"test_{self.calls:04d}.json", {"test": test, **result})
        # Full raw output is archived; the model receives a bounded observation.
        return {**result, "stdout": result["stdout"][:16000], "output_truncated": len(result["stdout"]) > 16000}

    def confirm(self) -> list[dict]:
        base = int(self.params["seed"])
        return [self.paired(seed=base + offset) for offset in (1000, 2000)]


def snapshot(workspace: Path, destination: Path) -> dict:
    destination.mkdir(parents=True, exist_ok=False)
    hashes = {}
    paths = [workspace / "candidate.py"]
    library = workspace / "target_library"
    if library.is_symlink():
        raise ValueError("Production library cannot be a symbolic link")
    for directory, dirs, files in os.walk(library, followlinks=False):
        for name in dirs:
            if (Path(directory) / name).is_symlink():
                raise ValueError("Production directory cannot be a symbolic link")
        paths.extend(Path(directory) / name for name in files if name.endswith(".py"))
    for path in sorted(paths):
        if not path.exists() and not path.is_symlink():
            continue
        info = path.lstat()
        if not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
            raise ValueError("Production snapshots require regular, unlinked files")
        relative = path.relative_to(workspace)
        out = destination / relative
        out.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(path, out)
        hashes[str(relative)] = digest(path)
    return hashes
