"""Unprivileged Linux restrictions for agent-created tests.

Landlock limits filesystem access to the episode and installed runtimes. The
parent retains the LLM credentials; child environments contain no credentials.
The rules are installed before executing any candidate/test code.
"""
from __future__ import annotations

import argparse
import ctypes
import errno
import os
from pathlib import Path
import socket
import subprocess
import sys
import time

READ = (1 << 0) | (1 << 2) | (1 << 3)
WRITE = (1 << 1) | sum(1 << n for n in range(4, 13))


def restrict(read_paths: list[str], write_paths: list[str], *, network: bool = False) -> None:
    libc = ctypes.CDLL(None, use_errno=True)
    abi = libc.syscall(444, 0, 0, 1)
    if abi < 1:
        raise RuntimeError("Landlock unavailable; refusing unrestricted test execution")
    handled = READ | WRITE
    if abi >= 2:
        handled |= 1 << 13  # cross-directory rename/link
    if abi >= 3:
        handled |= 1 << 14  # truncate
    if abi >= 5:
        handled |= 1 << 15  # device ioctl
    class Ruleset(ctypes.Structure):
        _fields_ = [("handled_access_fs", ctypes.c_uint64)]
    class PathBeneath(ctypes.Structure):
        _pack_ = 1
        _fields_ = [("allowed_access", ctypes.c_uint64), ("parent_fd", ctypes.c_int)]
    attr = Ruleset(handled)
    fd = libc.syscall(444, ctypes.byref(attr), ctypes.sizeof(attr), 0)
    if fd < 0:
        raise OSError(ctypes.get_errno(), "landlock_create_ruleset")
    try:
        for name, writable in [(p, False) for p in read_paths] + [(p, True) for p in write_paths]:
            p = Path(name).resolve()
            if not p.exists():
                continue
            access = handled if writable else READ
            if not p.is_dir():
                access &= (1 << 0) | (1 << 1) | (1 << 2) | (1 << 14) | (1 << 15)
            path_fd = os.open(p, os.O_PATH | os.O_CLOEXEC)
            try:
                rule = PathBeneath(access, path_fd)
                if libc.syscall(445, fd, 1, ctypes.byref(rule), 0) < 0:
                    raise OSError(ctypes.get_errno(), "landlock_add_rule: " + str(p))
            finally:
                os.close(path_fd)
        if libc.prctl(38, 1, 0, 0, 0) < 0:
            raise OSError(ctypes.get_errno(), "PR_SET_NO_NEW_PRIVS")
        if libc.syscall(446, fd, 0) < 0:
            raise OSError(ctypes.get_errno(), "landlock_restrict_self")
    finally:
        os.close(fd)
    if not network:
        sec = ctypes.CDLL("libseccomp.so.2")
        sec.seccomp_init.argtypes = [ctypes.c_uint32]
        sec.seccomp_init.restype = ctypes.c_void_p
        sec.seccomp_rule_add.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_int, ctypes.c_uint]
        class ArgCompare(ctypes.Structure):
            _fields_ = [("arg", ctypes.c_uint), ("op", ctypes.c_int),
                        ("datum_a", ctypes.c_uint64), ("datum_b", ctypes.c_uint64)]
        sec.seccomp_rule_add_array.argtypes = [ctypes.c_void_p, ctypes.c_uint32,
                                              ctypes.c_int, ctypes.c_uint,
                                              ctypes.POINTER(ArgCompare)]
        sec.seccomp_load.argtypes = [ctypes.c_void_p]
        sec.seccomp_release.argtypes = [ctypes.c_void_p]
        sec.seccomp_syscall_resolve_name.argtypes = [ctypes.c_char_p]
        ctx = sec.seccomp_init(0x7FFF0000)
        if not ctx:
            raise RuntimeError("seccomp_init failed")
        try:
            # A connect-only restriction leaves unconnected UDP sendto available.
            # Keep local socketpair/AF_UNIX support required by asyncio, while
            # denying creation of network sockets before any candidate runs.
            socket_nr = sec.seccomp_syscall_resolve_name(b"socket")
            non_unix = ArgCompare(0, 1, socket.AF_UNIX, 0)  # SCMP_CMP_NE
            if socket_nr < 0 or sec.seccomp_rule_add_array(
                    ctx, 0x00050000 | errno.EPERM, socket_nr, 1, ctypes.byref(non_unix)) != 0:
                raise RuntimeError("seccomp network socket restriction failed")
            for call in (b"connect", b"ptrace", b"process_vm_readv", b"process_vm_writev"):
                nr = sec.seccomp_syscall_resolve_name(call)
                if nr >= 0 and sec.seccomp_rule_add(ctx, 0x00050000 | errno.EPERM, nr, 0) != 0:
                    raise RuntimeError("seccomp_rule_add failed")
            if sec.seccomp_load(ctx) != 0:
                raise RuntimeError("seccomp_load failed")
        finally:
            sec.seccomp_release(ctx)


def runtime_reads(python: Path) -> list[str]:
    return [str(python.parent.parent), "/usr", "/lib", "/lib64", "/bin",
            "/etc/ld.so.cache", "/etc/localtime", "/etc/nsswitch.conf", "/etc/passwd",
            "/etc/group", "/proc/cpuinfo", "/proc/meminfo", "/proc/stat",
            "/proc/sys/kernel/osrelease", "/sys/devices/system/cpu", "/sys/devices/system/node"]


def run_isolated(workspace: Path, python: Path, script: Path, *, timeout: float = 120,
                 extra_reads: list[str] | None = None, extra_writes: list[str] | None = None,
                 writable: bool = False, args: list[str] | None = None) -> dict:
    workspace = workspace.resolve()
    temp = workspace / ".runtime"
    temp.mkdir(exist_ok=True)
    reads = runtime_reads(python) + [str(workspace), str(script.resolve())] + (extra_reads or [])
    writes = [str(temp), "/dev/null", "/dev/urandom", "/dev/random", "/dev/shm"] + (extra_writes or [])
    if writable:
        writes += [str(workspace / "candidate.py"), str(workspace / "target_library"), str(workspace / "scratch_tests")]
    cmd = [str(python), str(Path(__file__).resolve()), "--read", *reads, "--write", *writes,
           "--exec", str(python), str(script.resolve()), *(args or [])]
    env = {"PATH": str(python.parent) + ":/usr/bin:/bin", "PYTHONPATH": str(workspace),
           "PYTHONDONTWRITEBYTECODE": "1", "TMPDIR": str(temp),
           "LANG": "C.UTF-8", "OMP_NUM_THREADS": "1", "OPENBLAS_NUM_THREADS": "1",
           "MS_CACHE_PATH": str(temp), "GLOG_logtostderr": "1"}
    start = time.monotonic()
    try:
        result = subprocess.run(cmd, cwd=workspace, env=env, stdout=subprocess.PIPE,
                                stderr=subprocess.STDOUT, text=True, timeout=timeout,
                                start_new_session=True)
        return {"returncode": result.returncode, "stdout": result.stdout,
                "wall_time_sec": time.monotonic() - start, "isolation": "landlock+seccomp"}
    except subprocess.TimeoutExpired as exc:
        out = exc.stdout or b""
        return {"returncode": 124, "stdout": out.decode(errors="replace") if isinstance(out, bytes) else out,
                "wall_time_sec": time.monotonic() - start, "isolation": "landlock+seccomp", "timeout": True}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--read", nargs="*", default=[])
    parser.add_argument("--write", nargs="*", default=[])
    parser.add_argument("--exec", dest="command", nargs=argparse.REMAINDER, required=True)
    params = parser.parse_args()
    restrict(params.read, params.write)
    os.execv(params.command[0], params.command)


if __name__ == "__main__":
    main()
