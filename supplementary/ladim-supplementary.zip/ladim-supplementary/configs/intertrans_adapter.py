"""Original InterTrans graph search with visible-only N18 Docker training tests."""
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import sys
import time
from verify_candidate import prepare,evaluate,save

HERE=Path(__file__).resolve().parent


def prepare_assets(index,tasks,destination):
    destination.mkdir(parents=True,exist_ok=True)
    # Public shape/asset contracts only. Expected outputs never enter container assets.
    for task in tasks:
        reference=Path(index['tasks'][task]['reference_root'])
        prepare(reference,destination/'public'/task,task,101)
    shutil.copy2(HERE.parent/'intertrans/n18_check.py',destination/'n18_check.py')


def run(task,reference,case,prompt,source,engine,assets,image):
    assert os.getenv('AUTOFIX_LLM_API_KEY') and os.getenv('AUTOFIX_LLM_MODEL')=='deepseek-v4-flash'
    sys.path.extend([os.environ['AUTOFIX_INTERTRANS_CLIENT_SITE'],
                     os.environ['AUTOFIX_INTERTRANS_CLIENT_ROOT']])
    import grpc
    import yaml
    from intertrans import protos_pb2 as pb,protos_pb2_grpc as rpc
    from google.protobuf.json_format import MessageToDict
    case.mkdir(parents=True,exist_ok=True)
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    contract=json.loads((assets/'public'/task/'fixture.json').read_text())['context']
    common=(HERE.parent/'training_interface.txt').read_text()
    template='Translate the COMPLETE {input_lang} program to {target_lang}, preserving all source training behavior. If the target is Python, implement the following extra training interface using the SAME translated operations. Return the complete code in a code fence.\n'+common+'\nPublic interface metadata for the final Python target:\n'+json.dumps(contract)+'\nSource program:\n{input_code}'
    config=dict(numExecutionWorkers=1,numInferenceWorkers=1,useComputeEfficientMode=True,
        serverAddress='127.0.0.1',serverPort=port,earlyStop=False,verifyIntermediateTranslations=False,
        expansionIntermediaryNodes=3,applyRegexInferenceOnly=True,useTranscoderTestFormat=False,
        useInferenceCache=False,useResponseCache=False,useExecutionCache=False,cacheDatabasePath=str(case/'cache'),
        maxGeneratedTokens=int(os.getenv('AUTOFIX_LLM_MAX_TOKENS', '0')),temperature=.1,inferenceSeed=-1,
        inferenceApiBaseUrls=[os.getenv('AUTOFIX_LLM_BASE_URL','https://api.deepseek.com').rstrip('/')],
        inferenceApiToken=os.environ['AUTOFIX_LLM_API_KEY'],executionContainers={'Python':image},
        regexTemplates={'fenced':r'(?s)```(?:python|java|javascript|js)?\s*(.*?)```'},promptTemplates={'n18':template})
    config['top-p']=.95
    private=case/'private_config.yaml'
    fd=os.open(private,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    with os.fdopen(fd,'w') as f:yaml.safe_dump(config,f)
    env=os.environ.copy();env.update(INTERTRANS_EXECUTOR='docker',INTERTRANS_N18_ASSET_ROOT=str(case/'visible_service'),INTERTRANS_USAGE_LOG=str(case/'usage.jsonl'))
    from autofix.backends.visible_service import serve
    from external_method_adapters import ordinary
    service_dir=case/'visible_service';service_dir.mkdir(exist_ok=True)
    shutil.copy2(HERE.parent/'intertrans/n18_check.py',service_dir/'n18_check.py')
    serial=[0]
    def visible(code):
        serial[0]+=1;directory=case/f'visible_rpc_{serial[0]}';directory.mkdir()
        candidate=directory/'candidate.py';candidate.write_text(code)
        return ordinary(evaluate(candidate,reference,directory/'measurement',task,101))
    service=serve(service_dir,visible)
    service.__enter__()
    channel=grpc.insecure_channel(f'127.0.0.1:{port}',options=[('grpc.max_receive_message_length',64*1024*1024)])
    start=time.monotonic();result={}
    with (case/'server.log').open('w') as log:
        proc=subprocess.Popen([str(engine),'runserver',str(private)],cwd=case,env=env,stdout=log,stderr=subprocess.STDOUT)
        try:
            grpc.channel_ready_future(channel).result(timeout=30)
            test='if __name__ == "intertrans_candidate":\n import sys\n sys.path.insert(0,"/n18")\n from n18_check import check_candidate\n check_candidate(__file__,'+repr(task)+')\n'
            request=pb.BatchTranslationRequest(id='n18-'+task,translation_requests=[pb.TranslationRequest(id=task,seed_language='Java',target_language='Python',seed_code=source,used_languages=['JavaScript','Python'],prompt_template_name='n18',regex_template_name='fenced',model_name='deepseek-v4-flash',test_suite=pb.TestSuite(unit_test_suite=[pb.UnitTestCase(language='Python',test_case=test)]))])
            response=rpc.TranslationServiceStub(channel).BatchTranslate(request,timeout=3600)
            save(case/'response.json',MessageToDict(response,preserving_proto_field_name=True))
            edges=[e for r in response.translation_responses for p in r.paths for e in p.translation_edges]
            good=[e for e in edges if e.target_language=='Python' and e.status=='TRANSLATION_FOUND' and e.unit_tests and all(t.passed for t in e.unit_tests)]
            # Search completion and unsuccessful paths are retained even with no accepted target.
            if good:
                selected=good[0]
                code=selected.extracted_source_code
                (case/'candidate.py').write_text(code)
                # Only remap declared shared-asset paths when moving out of Docker.
                # This is a runtime path mapping, never a semantic code repair.
                fixture=prepare(reference,case/'host_contract',task,101)
                for name,path in fixture['context']['assets'].items():
                    code=code.replace(contract['assets'][name],path)
                (case/'host_candidate.py').write_text(code)
                scores=[evaluate(case/'host_candidate.py',reference,case/f'seed_{seed}',task,seed) for seed in (101,202,303)]
                result=dict(task=task,status='evaluated',passed=all(r['passed'] for r in scores),selected_edge_id=selected.edge_id,
                    seeds=[dict(seed=r['seed'],passed=r['passed'],stage=r['stage']) for r in scores])
            else:
                missing=any(e.status=='FAILED_NO_EXTRACTED' for e in edges)
                result=dict(task=task,status='generation_or_extraction_error' if missing else 'search_exhausted',passed=None if missing else False)
            result['paths']=[dict(edges=[dict(id=e.edge_id,source=e.input_language,target=e.target_language,status=e.status) for e in p.translation_edges]) for r in response.translation_responses for p in r.paths]
        except Exception as exc:result=dict(task=task,status='infrastructure_error',passed=None,error_type=type(exc).__name__)
        finally:
            channel.close();proc.terminate()
            try:proc.wait(timeout=15)
            except subprocess.TimeoutExpired:proc.kill();proc.wait()
            private.unlink(missing_ok=True)
            service.__exit__(None,None,None)
    result.update(elapsed_sec=time.monotonic()-start,full_program_certified=False,
                  intermediate_language='JavaScript',intermediate_execution_validated=False)
    save(case/'result.json',result);return result
