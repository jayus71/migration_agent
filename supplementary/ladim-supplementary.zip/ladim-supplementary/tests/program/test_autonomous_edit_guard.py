import tempfile
import unittest
from pathlib import Path

from autofix.autonomous.tools import WorkspaceTools, ToolError


class EditGuardTests(unittest.TestCase):
    def test_multifile_syntax_failure_preserves_all_original_files_and_can_retry(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "candidate.py").write_text("value = 1\n")
            (root / "target_library").mkdir()
            (root / "target_library/ops.py").write_text("def f():\n    return 2\n")
            tools = WorkspaceTools(root, lambda _: {}, validate_syntax=True)
            edits = [{"path": "candidate.py", "old": "1", "new": "3"},
                     {"path": "target_library/ops.py", "old": "return 2", "new": "return ("}]
            with self.assertRaisesRegex(ToolError, "target_library/ops.py:2"):
                tools.execute("edit", {"edits": edits})
            self.assertEqual((root / "candidate.py").read_text(), "value = 1\n")
            self.assertEqual((root / "target_library/ops.py").read_text(), "def f():\n    return 2\n")
            self.assertEqual(tools.edit_records, [])
            edits[1]["new"] = "return 4"
            self.assertTrue(tools.execute("edit", {"edits": edits})["ok"])
            self.assertEqual((root / "candidate.py").read_text(), "value = 3\n")
            self.assertEqual(len(tools.edit_records), 1)

    def test_guard_never_executes_candidate_code(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            (root / "candidate.py").write_text("value = 1\n")
            tools = WorkspaceTools(root, lambda _: {}, validate_syntax=True)
            tools.execute("edit", {"edits": [{"path": "candidate.py", "old": "value = 1",
                                               "new": "raise RuntimeError('must not execute')"}]})
            self.assertEqual(len(tools.edit_records), 1)
