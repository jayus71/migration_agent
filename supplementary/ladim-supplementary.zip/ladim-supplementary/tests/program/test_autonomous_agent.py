"""Offline behavioral checks for tools, budget accounting and the audit trail."""

from __future__ import annotations

import json
import os
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

from autofix.autonomous import AgentConfig, AutonomousAgent, BudgetExhausted, ToolError, WorkspaceTools
from autofix.autonomous.agent import SYSTEM_PROMPT, FIXER_PROMPT, LIBRARY_UNIT_SYSTEM_PROMPT, LIBRARY_UNIT_FIXER_PROMPT, EVIDENCE_SYSTEM_PROMPT, EVIDENCE_FIXER_PROMPT, LIBRARY_UNIT_EVIDENCE_SYSTEM_PROMPT, LIBRARY_UNIT_EVIDENCE_FIXER_PROMPT


def answer(content=None, calls=None, *, tokens=8, model="provider-actual-model"):
    message = {"role": "assistant", "content": content}
    if calls:
        message["tool_calls"] = [{"id": f"call_{name}_{index}", "type": "function",
                                   "function": {"name": name, "arguments": json.dumps(args)}}
                                  for index, (name, args) in enumerate(calls)]
    return {"model": model, "choices": [{"message": message, "finish_reason": "tool_calls" if calls else "stop"}],
            "usage": {"prompt_tokens": 13, "completion_tokens": tokens, "total_tokens": tokens + 13}}


def final_answer(category="unintended arithmetic"):
    return answer(json.dumps({"diagnosis": {"category": category,
        "locations": [{"path": "candidate.py", "symbol_or_lines": "1", "reason": "comparison"}],
        "evidence": ["candidate.py:1 returns x + 2; source.py:1 returns x + 1"],
        "uncertainty": ""}, "summary": "Investigated the observed output difference."}))


def tool_answer(round_number, calls):
    response = answer(calls=calls)
    for call in response["choices"][0]["message"]["tool_calls"]:
        call["id"] = f"round_{round_number}_" + call["id"]
    return response


class FakeClient:
    def __init__(self, responses):
        self.responses = iter(responses)
        self.requests = []

    def __call__(self, request, timeout_seconds):
        self.requests.append(request)
        return next(self.responses)


class WorkspaceTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name) / "workspace"
        self.root.mkdir()
        (self.root / "candidate.py").write_text("def f(x): return x + 2\n")
        (self.root / "source.py").write_text("def f(x): return x + 1\n")
        (self.root / "task.json").write_text('{"comparison": "same output"}')
        (self.root / "target_library").mkdir()
        (self.root / "target_library" / "ops.py").write_text("scale = 3\n")
        (self.root / "private_score.py").write_text("answer = 'secret'\n")
        self.runs = []
        def runner(request):
            self.runs.append(request)
            return {"execution": "ok", "difference": 1.0}
        self.tools = WorkspaceTools(self.root, runner)

    def tearDown(self):
        self.temp.cleanup()

    def agent(self, responses, **config):
        # Individual legacy-policy tests keep their explicit, minimal stage setup.
        config.setdefault("workflow_policy", "standard")
        config.setdefault("memory_policy", "native")
        client = FakeClient(responses)
        agent = AutonomousAgent(self.tools, Path(self.temp.name) / "logs",
                                config=AgentConfig(**config), client=client)
        return agent, client

    def test_allowlist_and_path_attacks(self):
        names = self.tools.execute("list", {})["files"]
        self.assertEqual(names, sorted(["candidate.py", "source.py", "task.json", "target_library/ops.py"]))
        for path in ("../source.py", "/etc/passwd", "target_library/../../private_score.py",
                     "target_library/../candidate.py", "private_score.py", "C:/secret.py",
                     "target_library\\ops.py", "target_library/.hidden.py", "./candidate.py"):
            with self.subTest(path=path), self.assertRaises(ToolError):
                self.tools.execute("read", {"path": path})

    def test_symlinks_and_hardlinks_are_neither_readable_nor_editable(self):
        outside = Path(self.temp.name) / "outside.py"
        outside.write_text("outside = 1\n")
        (self.root / "target_library" / "linked.py").symlink_to(outside)
        os.link(outside, self.root / "target_library" / "hard.py")
        for filename in ("linked.py", "hard.py"):
            path = "target_library/" + filename
            with self.subTest(path=path), self.assertRaises(ToolError):
                self.tools.execute("read", {"path": path})
            with self.assertRaises(ToolError):
                self.tools.execute("edit", {"edits": [{"path": path, "old": "1", "new": "2"}]})
        self.assertEqual(outside.read_text(), "outside = 1\n")

    def test_source_task_and_diagnosis_are_immutable(self):
        for path, old in (("source.py", "x + 1"), ("task.json", "same output")):
            with self.assertRaises(ToolError):
                self.tools.execute("edit", {"edits": [{"path": path, "old": old, "new": "bad"}]})
        self.assertIn("edit", [tool["function"]["name"] for tool in self.tools.schemas(readonly=True)])
        with self.assertRaises(ToolError):
            self.tools.execute("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]}, readonly=True)
        result = self.tools.execute("edit", {"edits": [{"path": "scratch_tests/probe.py", "old": "", "new": "print(1)\n"}]}, readonly=True)
        self.assertTrue(result["ok"])
        self.tools.execute("run_test", {"test": "scratch_tests/probe.py"}, readonly=True)
        self.assertEqual(self.runs[-1]["test"], "scratch_tests/probe.py")

    def test_multi_file_edit_validates_every_replacement_before_mutation(self):
        initial = (self.root / "candidate.py").read_text()
        with self.assertRaises(ToolError):
            self.tools.execute("edit", {"edits": [
                {"path": "candidate.py", "old": "x + 2", "new": "x + 1"},
                {"path": "target_library/ops.py", "old": "does not exist", "new": "4"},
            ]})
        self.assertEqual((self.root / "candidate.py").read_text(), initial)
        result = self.tools.execute("edit", {"edits": [
            {"path": "candidate.py", "old": "x + 2", "new": "x + 1"},
            {"path": "target_library/ops.py", "old": "3", "new": "4"},
            {"path": "scratch_tests/check.py", "old": "", "new": "assert 1 + 1 == 2\n"},
        ]})
        self.assertEqual(len(result["files"]), 3)
        self.assertEqual(len(self.tools.edit_records), 1)
        self.assertIn("x + 1", (self.root / "candidate.py").read_text())

    def test_exact_edit_rejects_ambiguous_and_empty_old(self):
        (self.root / "candidate.py").write_text("x = 2\ny = 2\n")
        for old in ("2", ""):
            with self.assertRaises(ToolError):
                self.tools.execute("edit", {"edits": [{"path": "candidate.py", "old": old, "new": "1"}]})

    def test_test_callback_receives_no_shell_and_bounded_timeout(self):
        for test in ("bash -c true", "paired;env", "../private.py", "candidate.py", "source.py"):
            with self.subTest(test=test), self.assertRaises(ToolError):
                self.tools.execute("run_test", {"test": test})
        self.assertEqual(self.runs, [])
        self.tools.execute("run_test", {"test": "paired", "timeout_seconds": 900}, remaining_seconds=7)
        self.assertEqual(self.runs, [{"test": "paired", "timeout_seconds": 7}])

    def test_read_search_and_list_have_explicit_pagination(self):
        first = self.tools.execute("list", {"limit": 2})
        self.assertEqual(first["next_offset"], 2)
        self.assertEqual(self.tools.execute("list", {"offset": 2})["next_offset"], None)
        (self.root / "candidate.py").write_text("x = 1\nx = 2\nx = 3\n")
        read = self.tools.execute("read", {"path": "candidate.py", "max_lines": 1})
        self.assertEqual(read["next_line"], 2)
        search = self.tools.execute("search", {"query": "x =", "prefix": "candidate", "limit": 1})
        self.assertEqual(search["total"], 3)
        self.assertEqual(search["next_offset"], 1)

    def test_diagnosis_cannot_edit_even_if_model_requests_it(self):
        agent, client = self.agent([
            answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]})]),
            final_answer(),
        ])
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertIn("x + 2", (self.root / "candidate.py").read_text())
        self.assertIn("Diagnosis may edit only", client.requests[1]["messages"][-1]["content"])
        edit_schema = next(t for t in client.requests[0]["tools"] if t["function"]["name"] == "edit")
        self.assertIn("only scratch_tests", edit_schema["function"]["description"])

    def test_retries_preserve_diagnosis_and_edit_history(self):
        agent, client = self.agent([
            final_answer(),
            answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "x + 2", "new": "x + 1"}]})]),
            final_answer(), final_answer("confirmed arithmetic correction"),
        ])
        diagnosis = agent.diagnose({"difference": 1})
        repair = agent.repair({"execution": "ok", "accepted": False}, attempt=1)
        again = agent.repair({"accepted": False, "difference": 0.1}, attempt=2)
        self.assertEqual(diagnosis.diagnosis["category"], "unintended arithmetic")
        self.assertEqual(repair.edited_files, ["candidate.py"])
        self.assertEqual(again.calls, 1)
        transcript = json.dumps(client.requests[-1]["messages"])
        self.assertIn("unintended arithmetic", transcript)
        self.assertIn("after_sha256", transcript)
        self.assertIn('Repair attempt 2', transcript)

    def test_layered_uses_independent_fixer_with_complete_attributed_handoff(self):
        agent, client = self.agent([
            answer(calls=[("read", {"path": "candidate.py"})]), final_answer(), final_answer(),
        ], method="layered")
        agent.diagnose({"loss_difference": 0.4})
        original = json.loads(json.dumps(agent.history))
        agent.repair({"accepted": False})
        self.assertEqual(agent.verifier_history, original)
        self.assertEqual(agent.active_role, "fixer")
        fixer_messages = client.requests[2]["messages"]
        self.assertIn("repair role receiving an independent verifier", fixer_messages[0]["content"])
        # A fresh fixer has no assistant turns of its own on its first call.
        self.assertTrue(all(m["role"] != "assistant" for m in fixer_messages))
        handoff = [json.loads(m["content"])["verifier_record"] for m in fixer_messages
                   if m["content"].startswith('{"verifier_record":')]
        self.assertEqual(handoff, original[1:])
        self.assertEqual(agent.calls, 3)

    def test_single_preserves_one_continuous_conversation(self):
        agent, client = self.agent([final_answer(), final_answer()], method="single")
        agent.diagnose({"loss_difference": 0.4})
        agent.repair({"accepted": False})
        self.assertIsNone(agent.verifier_history)
        self.assertEqual(agent.active_role, "continuous_agent")
        self.assertTrue(any(m["role"] == "assistant" for m in client.requests[1]["messages"]))

    def test_last_stage_call_requires_summary_without_tools(self):
        agent, client = self.agent([
            answer(calls=[("read", {"path": "candidate.py"})]), final_answer(),
        ], diagnosis_calls_per_stage=2)
        result = agent.diagnose({"loss_difference": 0.4})
        self.assertEqual(result.status, "completed")
        self.assertIn("tools", client.requests[0])
        self.assertNotIn("tools", client.requests[1])
        self.assertIn("Tool execution is now disabled", client.requests[1]["messages"][-1]["content"])

    def test_lifetime_call_budget_covers_stages_and_low_level_baselines(self):
        agent, client = self.agent([final_answer(), final_answer()], max_calls=2)
        agent.complete([{"role": "user", "content": "Baseline analysis"}])
        agent.diagnose({"difference": 1})
        result = agent.repair({"accepted": False})
        self.assertEqual(result.status, "call_budget_exhausted")
        self.assertEqual(result.calls, 0)
        self.assertEqual(len(client.requests), 2)
        with self.assertRaisesRegex(BudgetExhausted, "call_budget"):
            agent.complete([{"role": "user", "content": "another analysis"}])

    def test_output_allowance_and_missing_usage_cannot_evade_budget(self):
        no_usage = final_answer()
        del no_usage["usage"]
        agent, client = self.agent([final_answer(), no_usage], max_output_tokens=12, per_call_output_tokens=10)
        agent.diagnose({"difference": 1})
        agent.repair({"accepted": False})
        result = agent.repair({"accepted": False}, attempt=2)
        self.assertEqual([r["max_tokens"] for r in client.requests], [10, 4])
        self.assertEqual(result.status, "output_budget_exhausted")
        self.assertEqual(result.usage["completion_tokens"], 8)
        self.assertEqual(result.usage["budget_output_tokens"], 12)
        self.assertEqual(result.usage["unknown_usage_calls"], 1)

    def test_every_request_response_and_actual_model_are_saved(self):
        agent, _ = self.agent([final_answer()], model="requested-alias")
        agent.diagnose({"difference": 1})
        self.assertTrue((agent.log_dir / "call_0001_request.json").exists())
        response = json.loads((agent.log_dir / "call_0001_response.json").read_text())
        self.assertEqual(response["model"], "provider-actual-model")
        session = json.loads((agent.log_dir / "session.json").read_text())
        self.assertEqual(session["usage"]["actual_models"], ["provider-actual-model"])
        self.assertEqual(session["usage"]["requested_model"], "requested-alias")

    def test_partial_usage_keeps_measured_input_and_reserves_unknown_output(self):
        response = final_answer()
        response["usage"] = {"prompt_tokens": 19}
        agent, _ = self.agent([response], per_call_output_tokens=25)
        result = agent.diagnose({"loss_difference": 0.4})
        self.assertEqual(result.usage["prompt_tokens"], 19)
        self.assertEqual(result.usage["completion_tokens"], 0)
        self.assertEqual(result.usage["budget_output_tokens"], 25)
        self.assertEqual(result.usage["unknown_usage_calls"], 1)

    def test_failed_api_is_recorded_without_exception_credentials(self):
        def failing(request, timeout):
            raise RuntimeError("Authorization: Bearer do-not-log-this-key")
        agent = AutonomousAgent(self.tools, Path(self.temp.name) / "logs", client=failing)
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "api_error")
        self.assertEqual(agent.calls, 1)
        self.assertTrue((agent.log_dir / "call_0001_request.json").exists())
        self.assertTrue((agent.log_dir / "call_0001_error.json").exists())
        self.assertFalse(any("do-not-log-this-key" in p.read_text() for p in agent.log_dir.glob("*.json")))

    def test_elapsed_budget_stops_without_api_or_tools(self):
        agent, client = self.agent([], max_seconds=1)
        agent.started -= 2
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "time_budget_exhausted")
        self.assertEqual(client.requests, [])

    def test_stage_budget_returns_to_controller_without_using_lifetime_budget(self):
        agent, client = self.agent([
            answer(calls=[("read", {"path": "candidate.py"})]), final_answer(),
        ], diagnosis_calls_per_stage=1, max_calls=3)
        initial = agent.diagnose({"difference": 1})
        self.assertEqual(initial.status, "stage_call_budget_exhausted")
        repair = agent.repair({"difference": 1}, attempt=1)
        self.assertEqual(repair.status, "completed")
        self.assertEqual(agent.calls, 2)
        self.assertEqual(len(client.requests), 2)

    def test_private_artifacts_are_absent_from_requests_and_unreadable(self):
        (self.root / "autofix" / "faults").mkdir(parents=True)
        (self.root / "autofix" / "faults" / "registry.py").write_text("ORACLE_CLASS = 'SECRET_FAULT_CLASS'\n")
        (self.root / "private_metadata.json").write_text('{"fault": "SECRET_FAULT_CLASS"}')
        agent, client = self.agent([
            answer(calls=[("read", {"path": "autofix/faults/registry.py"}), ("list", {})]),
            final_answer(),
        ])
        agent.diagnose({"execution": "ok", "loss_difference": 0.4})
        sent = json.dumps(client.requests)
        self.assertNotIn("SECRET_FAULT_CLASS", sent)
        self.assertNotIn("private_metadata.json", sent)
        self.assertIn("outside the public workspace allowlist", sent)

    def test_direct_control_uses_one_edit_operation(self):
        agent, _ = self.agent([
            answer(calls=[
                ("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]}),
                ("edit", {"edits": [{"path": "target_library/ops.py", "old": "3", "new": "4"}]}),
            ]), final_answer(),
        ], method="direct")
        result = agent.repair({"difference": 1})
        self.assertEqual(result.edited_files, ["candidate.py"])
        self.assertEqual((self.root / "target_library/ops.py").read_text(), "scale = 3\n")

    def test_context_compaction_is_explicit_and_preserves_edits_and_diagnosis(self):
        agent, _ = self.agent([], max_context_chars=10000, compact_tool_chars=1200, memory_policy="legacy")
        diagnosis_text = json.dumps(final_answer()["choices"][0]["message"])
        edit_content = json.dumps({"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]})
        agent.history.extend([
            {"role": "assistant", "content": diagnosis_text},
            {"role": "tool", "tool_call_id": "read1", "content": "HEAD" + "x" * 15000 + "TAIL"},
            {"role": "tool", "tool_call_id": "edit1", "content": edit_content},
            *[{"role": "user", "content": "next"} for _ in range(4)],
        ])
        agent.tool_records["read1"] = {"name": "read", "event": "original_read.json"}
        agent.tool_records["edit1"] = {"name": "edit", "event": "original_edit.json"}
        self.assertTrue(agent._compact_history())
        self.assertIn("context_compaction", agent.history[2]["content"])
        self.assertEqual(agent.history[1]["content"], diagnosis_text)
        self.assertEqual(agent.history[3]["content"], edit_content)
        self.assertIn("HEAD", agent.history[2]["content"])
        self.assertIn("TAIL", agent.history[2]["content"])

    def test_noncompactable_history_fails_explicitly(self):
        agent, client = self.agent([], max_context_chars=4000)
        result = agent.diagnose({"observation": "x" * 5000})
        self.assertEqual(result.status, "context_budget_exhausted")
        self.assertEqual(client.requests, [])
        self.assertIn("x" * 5000, json.dumps(agent.history))

    def test_logs_cannot_be_exposed_inside_public_workspace(self):
        with self.assertRaisesRegex(ValueError, "outside"):
            AutonomousAgent(self.tools, self.root / "scratch_tests", client=FakeClient([]))

    def test_library_unit_contract_runs_diagnosis_and_repair_without_source(self):
        (self.root / "source.py").unlink()
        (self.root / "task.json").write_text(json.dumps({"task_kind": "library_unit_repair",
            "runtime": "python", "interfaces": ["candidate.f"], "test_command": "public"}))
        report = answer(json.dumps({"diagnosis": {"category": "observed mismatch", "locations": [],
            "evidence": ["The public test reports an output difference."], "uncertainty": "Public tests cover the observed input."},
            "summary": "Investigated the declared unit-test contract."}))
        agent, client = self.agent([
            answer(calls=[("list", {}), ("read", {"path": "task.json"})]), report,
            answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "x + 2", "new": "x + 1"}]})]), report,
        ], task_kind="library_unit_repair", memory_policy="evidence")
        diagnosis = agent.diagnose({"execution": "passed", "output_difference": 1.0})
        repair = agent.repair({"execution": "passed", "output_difference": 1.0})
        self.assertEqual(diagnosis.status, "completed")
        self.assertEqual(repair.status, "completed")
        self.assertFalse((self.root / "source.py").exists())
        self.assertEqual(repair.edited_files, ["candidate.py"])
        self.assertEqual(client.requests[0]["messages"][0]["content"], LIBRARY_UNIT_EVIDENCE_SYSTEM_PROMPT)
        self.assertEqual(client.requests[2]["messages"][0]["content"], LIBRARY_UNIT_EVIDENCE_FIXER_PROMPT)
        for prompt in (LIBRARY_UNIT_SYSTEM_PROMPT, LIBRARY_UNIT_FIXER_PROMPT):
            self.assertIn("source.py is optional", prompt)
            self.assertIn("declared interfaces and runtime", prompt)
            self.assertNotIn("MindSpore", prompt)
            self.assertNotIn("Native PyTorch", prompt)
            self.assertNotIn("target training", prompt)
        protocol = json.loads((agent.log_dir / "protocol.json").read_text())
        self.assertEqual(protocol["config"]["task_kind"], "library_unit_repair")

    def test_framework_migration_remains_default_with_original_backend_contract(self):
        agent, client = self.agent([final_answer(), final_answer()])
        agent.diagnose({"difference": 1})
        agent.repair({"difference": 1})
        self.assertEqual(agent.config.task_kind, "framework_migration")
        self.assertEqual(client.requests[0]["messages"][0]["content"], EVIDENCE_SYSTEM_PROMPT)
        self.assertEqual(client.requests[1]["messages"][0]["content"], EVIDENCE_FIXER_PROMPT)
        self.assertIn("target_library/MindSpore", SYSTEM_PROMPT)

    def test_task_kind_uses_only_the_two_public_contracts(self):
        for invalid in ("unknown", "gradient_fault", "candidate_repair"):
            with self.subTest(task_kind=invalid), self.assertRaisesRegex(ValueError, "task_kind"):
                AgentConfig(task_kind=invalid)
        self.assertEqual(AgentConfig(task_kind="library_unit_repair").memory_policy, "evidence")
        with self.assertRaisesRegex(ValueError, "layered method only"):
            AgentConfig(method="single", task_kind="library_unit_repair", memory_policy="evidence")

    def test_provider_defaults_send_explicit_thinking_without_ineffective_temperature(self):
        with patch.dict(os.environ, {"AUTOFIX_LLM_TEMPERATURE": "0.7"}):
            agent, client = self.agent([final_answer()])
        agent.diagnose({"difference": 1})
        request = client.requests[0]
        self.assertEqual(request["thinking"], {"type": "enabled"})
        self.assertEqual(request["reasoning_effort"], "high")
        self.assertEqual(request["max_tokens"], 16384)
        self.assertNotIn("temperature", request)
        self.assertEqual((agent.config.max_output_tokens, agent.config.max_seconds, agent.config.max_context_chars),
                         (120000, 1800, 1000000))
        protocol = json.loads((agent.log_dir / "protocol.json").read_text())
        self.assertEqual(protocol["provider_parameters"]["configured_temperature"], 0.7)
        self.assertEqual(protocol["provider_parameters"]["sent_temperature"], None)

    def test_legacy_provider_request_is_explicitly_replayable(self):
        agent, client = self.agent([final_answer()], thinking_mode="provider_default", reasoning_effort="",
                                  max_output_tokens=60000, per_call_output_tokens=4096,
                                  max_seconds=1200, max_context_chars=160000, temperature=0.1)
        agent.diagnose({"difference": 1})
        request = client.requests[0]
        self.assertNotIn("thinking", request)
        self.assertNotIn("reasoning_effort", request)
        self.assertEqual(request["temperature"], 0.1)
        self.assertEqual(request["max_tokens"], 4096)

    def test_nonthinking_and_environment_are_resolved_once(self):
        agent, client = self.agent([final_answer()], thinking_mode="disabled", reasoning_effort="none", temperature=0)
        with patch.dict(os.environ, {"AUTOFIX_LLM_TEMPERATURE": "1.5", "AUTOFIX_LLM_REASONING_EFFORT": "max"}):
            agent.diagnose({"difference": 1})
        request = client.requests[0]
        self.assertEqual(request["thinking"], {"type": "disabled"})
        self.assertEqual(request["reasoning_effort"], "none")
        self.assertEqual(request["temperature"], 0)
        with self.assertRaisesRegex(ValueError, "conflicts"):
            AgentConfig(thinking_mode="enabled", reasoning_effort="none")

    def test_missing_prompt_usage_is_unknown_even_when_completion_is_reported(self):
        reply = final_answer()
        reply["usage"] = {"completion_tokens": 100,
                          "completion_tokens_details": {"reasoning_tokens": 80}}
        agent, _ = self.agent([reply])
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.usage["unknown_usage_calls"], 1)
        self.assertEqual(result.usage["unknown_prompt_usage_calls"], 1)
        self.assertEqual(result.usage["unknown_completion_usage_calls"], 0)
        self.assertEqual(result.usage["reasoning_tokens"], 80)
        self.assertEqual(result.usage["total_tokens"], 100)
        self.assertEqual(result.usage["budget_output_tokens"], 100)

    def test_reasoning_only_truncation_can_continue_without_hiding_cost(self):
        truncated = answer("", tokens=4096)
        truncated["choices"][0]["finish_reason"] = "length"
        truncated["choices"][0]["message"]["reasoning_content"] = "Incomplete provider reasoning"
        agent, client = self.agent([truncated, final_answer()], diagnosis_calls_per_stage=2)
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 2)
        self.assertEqual(result.usage["completion_tokens"], 4104)
        self.assertEqual(result.usage["truncated_calls"], 1)
        self.assertIn("Incomplete provider reasoning", json.dumps(client.requests[1]["messages"]))
        first = json.loads((agent.log_dir / "call_0001_completion_status.json").read_text())
        self.assertEqual(first["status"], "output_truncated")

    def test_final_call_empty_content_is_output_truncated_not_success(self):
        agent, _ = self.agent([answer("")], diagnosis_calls_per_stage=1)
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "output_truncated")
        self.assertIsNone(result.diagnosis)
        self.assertEqual(result.calls, 1)

    def test_length_limited_tool_requests_do_not_mutate_candidate(self):
        truncated = answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]})])
        truncated["choices"][0]["finish_reason"] = "length"
        agent, _ = self.agent([truncated], repair_calls_per_stage=1)
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "output_truncated")
        self.assertEqual(result.edited_files, [])
        self.assertIn("x + 2", (self.root / "candidate.py").read_text())

    def test_native_context_above_old_guard_is_sent_in_full(self):
        agent, client = self.agent([final_answer()], method="single")
        messages = [{"role": "user", "content": "x" * 200000}]
        agent.complete(messages)
        self.assertEqual(client.requests[0]["messages"], messages)
        self.assertFalse(list(agent.log_dir.glob("event_*_evidence_memory.json")))

    def test_repair_loop_continues_premature_final_then_requires_actual_test(self):
        agent, client = self.agent([
            final_answer(),
            answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]})]),
            final_answer(),
            answer(calls=[("run_test", {"test": "public"})]),
            final_answer(),
        ], workflow_policy="repair_loop")
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 5)
        self.assertEqual(result.edited_files, ["candidate.py"])
        self.assertIn("No production edit", json.dumps(client.requests[1]["messages"]))
        self.assertIn("Production code changed", json.dumps(client.requests[3]["messages"]))
        self.assertEqual(len(self.runs), 1)

    def test_repair_loop_marks_investigation_only_at_fixed_stage_cap(self):
        agent, _ = self.agent([final_answer(), final_answer()], workflow_policy="repair_loop", repair_calls_per_stage=2)
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "investigation_only")
        self.assertEqual(result.calls, 2)
        self.assertEqual(result.edited_files, [])

    def test_repair_loop_keeps_untested_patch_for_external_acceptance_without_claiming_validation(self):
        agent, _ = self.agent([
            answer(calls=[("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]})]),
            final_answer(),
        ], workflow_policy="repair_loop", repair_calls_per_stage=2)
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "unvalidated_repair")
        self.assertEqual(result.edited_files, ["candidate.py"])
        self.assertEqual(self.runs, [])

    def test_repair_loop_is_opt_in_for_ours_only(self):
        self.assertEqual(AgentConfig().workflow_policy, "progress_loop")
        for method in ("single", "direct"):
            with self.assertRaisesRegex(ValueError, "layered method only"):
                AgentConfig(method=method, workflow_policy="repair_loop")

    def test_default_evidence_diagnosis_requires_no_category_and_hands_off_facts(self):
        payload = {"diagnosis": {"observations": ["Public output differs by 1"],
                   "locations": [{"path": "candidate.py", "symbol_or_lines": "1", "reason": "Inspected function"}],
                   "evidence": ["Observed public comparison"], "uncertainty": "Additional inputs remain untested"},
                   "hypotheses": [{"mechanism": "Arithmetic differs", "falsification_test": "Compare a second input"}],
                   "summary": "Recorded evidence without assigning a category"}
        agent, client = self.agent([answer(json.dumps(payload)), answer(json.dumps(payload))])
        diagnosis = agent.diagnose({"difference": 1})
        repair = agent.repair({"difference": 1})
        self.assertEqual(diagnosis.status, "completed")
        self.assertEqual(repair.status, "completed")
        self.assertNotIn("category", diagnosis.diagnosis)
        self.assertEqual(agent.config.diagnosis_policy, "evidence")
        first_prompt = client.requests[0]["messages"]
        self.assertNotIn("category", first_prompt[0]["content"])
        self.assertNotIn("category", first_prompt[-1]["content"])
        self.assertIn("observed outcomes", first_prompt[-1]["content"])
        self.assertIn("Public output differs by 1", json.dumps(client.requests[1]["messages"]))

    def test_category_ablation_preserves_original_prompt_and_validation(self):
        agent, client = self.agent([final_answer()], diagnosis_policy="category")
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(client.requests[0]["messages"][0]["content"], SYSTEM_PROMPT)
        self.assertIn("category and location", client.requests[0]["messages"][-1]["content"])
        _, parsed = agent._parse_final(json.dumps({"diagnosis": {"locations": [], "evidence": ["A measured result"]}}))
        self.assertIsNone(parsed)

    def test_evidence_diagnosis_still_requires_actual_evidence(self):
        agent, _ = self.agent([])
        _, parsed = agent._parse_final(json.dumps({"diagnosis": {"observations": [], "locations": [], "evidence": []}}))
        self.assertIsNone(parsed)
        with self.assertRaisesRegex(ValueError, "diagnosis_policy"):
            AgentConfig(diagnosis_policy="fault_route")

    def test_evidence_handoff_omits_only_verifier_reasoning_and_preserves_raw_record(self):
        source_reply = answer(calls=[("read", {"path": "candidate.py"})])
        source_reply["choices"][0]["message"]["reasoning_content"] = "Provider-private planning before inspecting source."
        verdict = final_answer()
        verdict["choices"][0]["message"]["reasoning_content"] = "Provider-private deliberation before the public diagnosis."
        agent, client = self.agent([source_reply, verdict, final_answer()], memory_policy="evidence")
        diagnosis = agent.diagnose({"difference": 1, "status": "observed"})
        before = json.loads(json.dumps(agent.history))
        agent.repair({"difference": 1})
        self.assertEqual(agent.verifier_history, before)
        forwarded = [json.loads(m["content"])["verifier_record"] for m in client.requests[2]["messages"]
                     if m.get("role") == "user" and m.get("content", "").startswith('{"verifier_record":')]
        expected = copy_records = json.loads(json.dumps(before[1:]))
        for record in copy_records:
            if record.get("role") == "assistant":
                record.pop("reasoning_content", None)
        self.assertEqual(forwarded, expected)
        self.assertEqual(agent.last_diagnosis, diagnosis.diagnosis)
        self.assertTrue(any(m.get("role") == "tool" and "candidate.py" in m["content"] for m in forwarded))
        archived = json.loads((agent.log_dir / "call_0001_response.json").read_text())
        self.assertEqual(archived, source_reply)
        event = json.loads(next(agent.log_dir.glob("event_*_handoff_evidence_compaction.json")).read_text())["data"]
        self.assertEqual(len(event["messages"]), 2)
        self.assertGreater(event["omitted_reasoning_chars"], 0)
        self.assertTrue(all(len(m["original_message_sha256"]) == 64 for m in event["messages"]))

    def test_native_handoff_retains_verifier_reasoning_without_ours_compaction(self):
        verdict = final_answer()
        verdict["choices"][0]["message"]["reasoning_content"] = "Original provider reasoning for native ablation."
        agent, client = self.agent([verdict, final_answer()], memory_policy="native")
        agent.diagnose({"difference": 1})
        before = json.loads(json.dumps(agent.history))
        agent.repair({"difference": 1})
        forwarded = [json.loads(m["content"])["verifier_record"] for m in client.requests[1]["messages"]
                     if m.get("role") == "user" and m.get("content", "").startswith('{"verifier_record":')]
        self.assertEqual(forwarded, before[1:])
        self.assertFalse(list(agent.log_dir.glob("event_*_handoff_evidence_compaction.json")))

    def test_progress_checkpoint_precedes_probe_and_validated_repair_within_budget(self):
        responses = [
            tool_answer(1, [("read", {"path": "candidate.py"})]),
            tool_answer(2, [("search", {"query": "return"})]),
            tool_answer(3, [("list", {})]),
            tool_answer(4, [
                ("edit", {"edits": [{"path": "scratch_tests/probe.py", "old": "", "new": "print(1)\n"}]}),
                ("run_test", {"test": "scratch_tests/probe.py"}),
            ]),
            tool_answer(5, [
                ("edit", {"edits": [{"path": "candidate.py", "old": "x + 2", "new": "x + 1"}]}),
                ("run_test", {"test": "public"}),
            ]), final_answer(),
        ]
        agent, client = self.agent(responses, workflow_policy="progress_loop", repair_calls_per_stage=6)
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 6)
        self.assertEqual([r["test"] for r in self.runs], ["scratch_tests/probe.py", "public"])
        self.assertIn("x + 1", (self.root / "candidate.py").read_text())
        checkpoint = client.requests[3]["messages"][-1]
        self.assertEqual(checkpoint["role"], "user")
        self.assertTrue(checkpoint["content"].startswith("Stage progress checkpoint:"))
        self.assertIn("how your next targeted read or search resolves it", checkpoint["content"])
        self.assertNotIn("x + 2", checkpoint["content"])
        self.assertIn("tools", client.requests[3])
        self.assertNotIn("tools", client.requests[-1])
        events = list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json"))
        self.assertEqual(len(events), 1)
        data = json.loads(events[0].read_text())["data"]
        self.assertEqual((data["call"], data["consecutive_inspection_calls"], data["stage_calls_remaining"]), (3, 3, 3))
        self.assertEqual(result.usage["completion_tokens"], 6 * 8)

    def test_progress_checkpoint_diagnosis_preserves_readonly_tools(self):
        agent, client = self.agent([
            *[tool_answer(i, [("read", {"path": "candidate.py"})]) for i in range(1, 4)],
            tool_answer(4, [
                ("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]}),
                ("edit", {"edits": [{"path": "scratch_tests/probe.py", "old": "", "new": "print(1)\n"}]}),
                ("run_test", {"test": "scratch_tests/probe.py"}),
            ]), final_answer(),
        ], workflow_policy="progress_loop", diagnosis_calls_per_stage=5)
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.edited_files, ["scratch_tests/probe.py"])
        self.assertIn("x + 2", (self.root / "candidate.py").read_text())
        self.assertIn("remain immutable during diagnosis", client.requests[3]["messages"][-1]["content"])
        self.assertEqual([r["test"] for r in self.runs], ["scratch_tests/probe.py"])
        self.assertIn("Diagnosis may edit only", json.dumps(client.requests[4]["messages"]))

    def test_progress_checkpoint_ignoring_advice_cannot_expand_stage_budget(self):
        agent, client = self.agent([
            *[tool_answer(i, [("read", {"path": "candidate.py"})]) for i in range(1, 8)],
            final_answer(),
        ], workflow_policy="progress_loop")
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "investigation_only")
        self.assertEqual(result.calls, 8)
        self.assertEqual(result.edited_files, [])
        self.assertEqual(self.runs, [])
        self.assertEqual(len(list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json"))), 1)
        self.assertEqual(len(list(agent.log_dir.glob("event_*_repair_loop_checkpoint.json"))), 1)
        self.assertNotIn("tools", client.requests[-1])

    def test_progress_checkpoint_keeps_summary_reservation_for_stage_and_lifetime_caps(self):
        for limits in ({"diagnosis_calls_per_stage": 4}, {"max_calls": 4}):
            with self.subTest(limits=limits), tempfile.TemporaryDirectory() as log:
                client = FakeClient([
                    *[tool_answer(i, [("read", {"path": "candidate.py"})]) for i in range(1, 4)],
                    final_answer(),
                ])
                agent = AutonomousAgent(self.tools, log, client=client,
                    config=AgentConfig(workflow_policy="progress_loop", **limits))
                result = agent.diagnose({"difference": 1})
                self.assertEqual(result.calls, 4)
                self.assertFalse(list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json")))
                self.assertNotIn("tools", client.requests[-1])
                self.assertIn("final model call", client.requests[-1]["messages"][-1]["content"])

    def test_progress_checkpoint_counts_rounds_and_resets_after_execution_or_edit(self):
        agent, client = self.agent([
            tool_answer(1, [("read", {"path": "candidate.py"}), ("search", {"query": "return"}), ("list", {})]),
            tool_answer(2, [("read", {"path": "source.py"})]),
            tool_answer(3, [("run_test", {"test": "public"}), ("read", {"path": "candidate.py"})]),
            tool_answer(4, [("search", {"query": "return"})]),
            tool_answer(5, [("edit", {"edits": [{"path": "scratch_tests/probe.py", "old": "", "new": "print(1)\n"}]})]),
            tool_answer(6, [("read", {"path": "candidate.py"})]),
            tool_answer(7, [("read", {"path": "source.py"})]),
            final_answer(),
        ], workflow_policy="progress_loop")
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 8)
        self.assertEqual(len(self.runs), 1)
        self.assertFalse(list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json")))

    def test_progress_checkpoint_resets_for_each_stage_and_inherits_validation_guard(self):
        responses = []
        for start in (1, 6):
            responses.extend(tool_answer(i, [("read", {"path": "candidate.py"})]) for i in range(start, start + 3))
            path = "scratch_tests/probe.py" if start == 1 else "candidate.py"
            old, new = ("", "print(1)\n") if start == 1 else ("2", "1")
            responses.append(tool_answer(start + 3, [("edit", {"edits": [{"path": path, "old": old, "new": new}]})]))
            responses.append(final_answer())
        agent, _ = self.agent(responses, workflow_policy="progress_loop", diagnosis_calls_per_stage=5,
                              repair_calls_per_stage=5, max_calls=10)
        diagnosis = agent.diagnose({"difference": 1})
        repaired = agent.repair({"difference": 1})
        self.assertEqual(diagnosis.status, "completed")
        self.assertEqual(repaired.status, "unvalidated_repair")
        self.assertEqual(agent.calls, 10)
        checkpoints = [json.loads(p.read_text())["data"] for p in sorted(agent.log_dir.glob("event_*_stage_progress_checkpoint.json"))]
        self.assertEqual([(d["stage"], d["call"]) for d in checkpoints], [("diagnose", 3), ("repair", 8)])

    def test_progress_checkpoint_is_default_and_preserves_explicit_prior_workflows(self):
        self.assertEqual(AgentConfig().workflow_policy, "progress_loop")
        for method in ("single", "direct"):
            with self.subTest(method=method), self.assertRaisesRegex(ValueError, "layered method only"):
                AgentConfig(method=method, workflow_policy="progress_loop")
        for policy in ("standard", "repair_loop"):
            with self.subTest(policy=policy), tempfile.TemporaryDirectory() as log:
                client = FakeClient([
                    *[tool_answer(i, [("read", {"path": "candidate.py"})]) for i in range(1, 4)],
                    tool_answer(4, [("run_test", {"test": "public"})]), final_answer(),
                ])
                agent = AutonomousAgent(self.tools, log, client=client,
                    config=AgentConfig(workflow_policy=policy, diagnosis_calls_per_stage=5))
                result = agent.diagnose({"difference": 1})
                self.assertEqual(result.status, "completed")
                self.assertFalse(list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json")))
                self.assertNotIn("Stage progress checkpoint", json.dumps(client.requests))

    def test_progress_accounting_keeps_malformed_tool_names_recoverable(self):
        agent, client = self.agent([
            tool_answer(1, [({"invalid": "name"}, {})]), final_answer(),
        ], workflow_policy="progress_loop")
        result = agent.diagnose({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 2)
        self.assertIn("Tool request failed", client.requests[1]["messages"][-1]["content"])
        self.assertFalse(list(agent.log_dir.glob("event_*_stage_progress_checkpoint.json")))

    def test_slim_v4_edit_schema_contains_no_added_format_examples(self):
        shared = self.tools.schemas(readonly=True)
        original = json.loads(json.dumps(shared))
        agent, client = self.agent([final_answer()], workflow_policy="progress_loop")
        with patch.object(self.tools, "schemas", return_value=shared):
            agent.diagnose({"difference": 1})
        self.assertEqual(shared, original)
        sent_edit = next(t["function"] for t in client.requests[0]["tools"] if t["function"]["name"] == "edit")
        base_edit = next(t["function"] for t in original if t["function"]["name"] == "edit")
        self.assertEqual(sent_edit["parameters"], base_edit["parameters"])
        self.assertEqual(sent_edit, base_edit)

    def test_progress_top_level_edit_feedback_preserves_rejection_and_budgeted_recovery(self):
        original = (self.root / "candidate.py").read_text()
        invalid = {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}], "path": "candidate.py"}
        corrected = {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]}
        scripted = FakeClient([
            tool_answer(1, [("edit", invalid)]),
            tool_answer(2, [("edit", corrected), ("run_test", {"test": "public"})]),
            final_answer(),
        ])
        def client(request, timeout):
            if len(scripted.requests) == 1:
                self.assertEqual((self.root / "candidate.py").read_text(), original)
                self.assertEqual(self.tools.edit_records, [])
                rejection = json.loads(request["messages"][-1]["content"])
                self.assertFalse(rejection["ok"])
                self.assertNotIn("schema_feedback", rejection)
                self.assertEqual(rejection["error"], "Unknown or missing tool arguments")
            return scripted(request, timeout)
        agent = AutonomousAgent(self.tools, Path(self.temp.name) / "logs", client=client,
            config=AgentConfig(workflow_policy="progress_loop", repair_calls_per_stage=3))
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 3)
        self.assertEqual(len(self.tools.edit_records), 1)
        self.assertEqual(len(self.runs), 1)
        self.assertIn("x + 1", (self.root / "candidate.py").read_text())
        events = [json.loads(p.read_text())["data"] for p in sorted(agent.log_dir.glob("event_*_tool.json"))]
        self.assertEqual(events[0]["arguments"], invalid)
        self.assertEqual(events[1]["arguments"], corrected)
        self.assertNotIn("schema_feedback", events[1]["result"])

    def test_progress_nested_edit_feedback_preserves_transaction_before_model_retry(self):
        invalid = {"edits": [
            {"path": "candidate.py", "old": "2", "new": "1"},
            {"path": "target_library/ops.py", "old": "3", "replacement": "4"},
        ]}
        scripted = FakeClient([
            tool_answer(1, [("edit", invalid)]),
            tool_answer(2, [("edit", {"edits": [{"path": "candidate.py", "old": "2", "new": "1"}]}),
                            ("run_test", {"test": "public"})]), final_answer(),
        ])
        def client(request, timeout):
            if len(scripted.requests) == 1:
                self.assertIn("x + 2", (self.root / "candidate.py").read_text())
                self.assertEqual((self.root / "target_library" / "ops.py").read_text(), "scale = 3\n")
                self.assertEqual(self.tools.edit_records, [])
                rejection = json.loads(request["messages"][-1]["content"])
                self.assertNotIn("schema_feedback", rejection)
                self.assertEqual(rejection["error"], "Every edit requires only path, old and new")
            return scripted(request, timeout)
        agent = AutonomousAgent(self.tools, Path(self.temp.name) / "logs", client=client,
            config=AgentConfig(workflow_policy="progress_loop", repair_calls_per_stage=3))
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "completed")
        self.assertEqual(result.calls, 3)
        self.assertEqual(result.edited_files, ["candidate.py"])

    def test_progress_repeated_invalid_edits_do_not_auto_apply_or_gain_extra_calls(self):
        invalid = {"path": "candidate.py", "old": "2", "new": "1"}
        agent, client = self.agent([
            tool_answer(1, [("edit", invalid)]), tool_answer(2, [("edit", invalid)]), final_answer(),
        ], workflow_policy="progress_loop", repair_calls_per_stage=3)
        result = agent.repair({"difference": 1})
        self.assertEqual(result.status, "investigation_only")
        self.assertEqual(result.calls, 3)
        self.assertEqual(result.edited_files, [])
        self.assertEqual(self.tools.edit_records, [])
        self.assertIn("x + 2", (self.root / "candidate.py").read_text())
        feedback = json.loads(client.requests[1]["messages"][-1]["content"])
        self.assertNotIn("schema_feedback", feedback)
        self.assertFalse(feedback["ok"])
        self.assertNotIn("tools", client.requests[-1])

    def test_progress_format_feedback_does_not_change_shared_tools_or_prior_workflows(self):
        invalid = {"edits": [{"path": "scratch_tests/probe.py", "old": "", "new": "print(1)\n"}], "path": "scratch_tests/probe.py"}
        for policy in ("standard", "repair_loop"):
            with self.subTest(policy=policy), tempfile.TemporaryDirectory() as log:
                scripted = FakeClient([tool_answer(1, [("edit", invalid)]), final_answer()])
                agent = AutonomousAgent(self.tools, log, client=scripted, config=AgentConfig(workflow_policy=policy))
                result = agent.diagnose({"difference": 1})
                self.assertEqual(result.status, "completed")
                self.assertEqual(scripted.requests[0]["tools"], self.tools.schemas(readonly=True))
                rejection = json.loads(scripted.requests[1]["messages"][-1]["content"])
                self.assertEqual(rejection, {"ok": False, "error_type": "ToolError", "error": "Unknown or missing tool arguments"})
        with self.assertRaisesRegex(ToolError, "^Unknown or missing tool arguments$"):
            self.tools.execute("edit", invalid)
        self.assertEqual(self.tools.edit_records, [])


if __name__ == "__main__":
    unittest.main()
