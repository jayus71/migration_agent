import copy
import json
import unittest

from autofix.autonomous.observations import build_observation, evaluate_acceptance, sanitize_runtime_text


def paired_payload():
    return {
        "config": {"mode": "train"},
        "results": {"torch": {"status": "ok"}, "target_library": {"status": "ok"}},
        "comparison": {"last_step_abs_loss_diff": 0.0, "last_step_abs_grad_norm_diff": 0.0, "param_update_rel_l2": 0.0},
        "layer_outputs": {"torch": {"layer": -1.0}, "target_library": {"layer": -1.0}},
    }


def accepted(observation):
    return evaluate_acceptance(observation, backend_attested=True, source_immutable=True)["accepted"]


class AutonomousObservationTests(unittest.TestCase):
    def test_private_answers_do_not_change_observation(self):
        clean = paired_payload()
        contaminated = copy.deepcopy(clean)
        contaminated.update({
            "fault_id": "GR-05", "failure_type": "secret_type", "root_cause_ranked": ["SECRET_ANSWER"],
            "fix_hints": ["SECRET_PATCH"], "metadata": {"recommended_target_files": ["SECRET_FILE"], "observed_probe": "SECRET_PROBE"},
        })
        contaminated["comparison"]["root_cause_ranked"] = ["SECRET_NESTED"]
        contaminated["results"]["target_library"]["failure_type"] = "SECRET_RESULT"
        first = build_observation(clean, command_returncode=0)
        second = build_observation(contaminated, command_returncode=0, stdout=json.dumps(contaminated))
        self.assertEqual(first, second)
        self.assertNotIn("SECRET", json.dumps(second))

    def test_failed_execution_discards_residual_zero_metrics(self):
        for failure in ("command", "reference", "target"):
            with self.subTest(failure=failure):
                payload = paired_payload()
                returncode = 1 if failure == "command" else 0
                if failure != "command":
                    payload["results"]["torch" if failure == "reference" else "target_library"]["status"] = "failed"
                observation = build_observation(payload, command_returncode=returncode)
                self.assertFalse(accepted(observation))
                self.assertTrue(all(item["value"] is None and item["status"] == "unavailable" for item in observation["measurements"].values()))
                self.assertEqual(observation["layer_differences"], [])

    def test_missing_execution_status_is_not_success(self):
        payload = paired_payload()
        del payload["results"]["target_library"]["status"]
        observation = build_observation(payload, command_returncode=0)
        self.assertEqual(observation["execution"]["target"]["status"], "unavailable")
        self.assertFalse(accepted(observation))

    def test_malformed_status_fails_closed(self):
        for value in (True, {}, ["ok"], None):
            with self.subTest(value=value):
                payload = paired_payload()
                payload["results"]["target_library"]["status"] = value
                observation = build_observation(payload, command_returncode=0)
                self.assertFalse(accepted(observation))

    def test_non_numbers_nonfinite_and_negative_metrics_fail(self):
        for value in (None, True, "0.0", float("nan"), float("inf"), -1.0):
            with self.subTest(value=value):
                payload = paired_payload()
                payload["comparison"]["last_step_abs_grad_norm_diff"] = value
                observation = build_observation(payload, command_returncode=0)
                self.assertFalse(accepted(observation))
                self.assertIsNone(observation["measurements"]["grad_norm_abs_diff"]["value"])
                json.dumps(observation, allow_nan=False)

    def test_inference_zero_metrics_cannot_pass_training(self):
        payload = paired_payload()
        payload["config"]["mode"] = "eval_forward"
        observation = build_observation(payload, command_returncode=0)
        self.assertFalse(accepted(observation))
        self.assertIsNone(observation["measurements"]["param_update_rel_l2"]["value"])
        self.assertTrue(evaluate_acceptance(observation, require_training=False, backend_attested=True, source_immutable=True)["accepted"])

    def test_source_and_backend_are_independent_attestations(self):
        payload = paired_payload()
        payload.update({"backend_attested": True, "source_immutable": True})
        payload["config"]["use_target_library_env"] = True
        observation = build_observation(payload, command_returncode=0)
        self.assertFalse(evaluate_acceptance(observation)["accepted"])
        self.assertFalse(evaluate_acceptance(observation, backend_attested=True)["accepted"])
        self.assertTrue(accepted(observation))

    def test_missing_layer_is_not_masked_by_aggregate(self):
        payload = paired_payload()
        payload["layer_outputs"]["torch"]["missing"] = 5.0
        observation = build_observation(payload, command_returncode=0)
        self.assertFalse(accepted(observation))
        self.assertIn("layer_differences_coverage", evaluate_acceptance(observation)["reasons"])

    def test_observed_layer_mismatch_is_not_masked_by_loss(self):
        payload = paired_payload()
        payload["layer_outputs"]["target_library"]["layer"] = 2.0
        observation = build_observation(payload, command_returncode=0)
        verdict = evaluate_acceptance(observation, backend_attested=True, source_immutable=True)
        self.assertEqual(verdict["reasons"], ["layer_differences_agreement"])

    def test_parameter_telemetry_is_allowlisted_and_checked(self):
        payload = paired_payload()
        payload["comparison"]["parameter_update_diagnostics"] = {
            "failure_type": "SECRET_TYPE",
            "parameters": [{"name": "layer.weight", "reference_update_norm": 1.0,
                            "candidate_update_norm": 2.0, "update_diff_norm": 1.0,
                            "update_rel_l2": 1.0, "repair_scope": "SECRET_SCOPE"}],
        }
        observation = build_observation(payload, command_returncode=0)
        self.assertNotIn("SECRET", json.dumps(observation))
        self.assertFalse(accepted(observation))
        self.assertIn("parameter_updates_agreement", evaluate_acceptance(observation)["reasons"])

    def test_update_failure_is_distinct_from_loss_and_gradient(self):
        payload = paired_payload()
        payload["comparison"]["param_update_rel_l2"] = 0.5
        observation = build_observation(payload, command_returncode=0)
        verdict = evaluate_acceptance(observation, backend_attested=True, source_immutable=True)
        self.assertEqual(verdict["reasons"], ["param_update_rel_l2"])

    def test_runtime_paths_are_public_and_case_ids_are_removed(self):
        text = 'File "/private/NU-07-B/faulty.py", line 2; File "/private/work/target_library/ops/mtorch.py"; GR-05 FAULT_CASE_003'
        value = sanitize_runtime_text(text, {"/private/NU-07-B/faulty.py": "candidate.py"})
        self.assertIn("candidate.py", value)
        self.assertIn("target_library/ops/mtorch.py", value)
        self.assertNotIn("private", value)
        self.assertNotIn("NU-07", value)
        self.assertNotIn("GR-05", value)
        self.assertNotIn("FAULT_CASE", value)

    def test_arbitrary_stdout_json_is_not_public_feedback(self):
        observation = build_observation({}, command_returncode=1, stdout='{"failure_type": "SECRET_ANSWER"}')
        self.assertNotIn("SECRET_ANSWER", json.dumps(observation))

    def test_caught_exception_keeps_actual_runtime_dispatch_log(self):
        payload = paired_payload()
        payload["results"]["target_library"] = {"status": "failed", "error": "RecursionError"}
        observation = build_observation(payload, command_returncode=0,
            stdout='{"fix_hints":"SECRET_ANSWER"}\n' +
                   'ERROR:target_library.tensor:Error during dispatch of __getitem__: recursion\n' * 200)
        diagnostics = observation["execution"]["runtime_diagnostics"]
        self.assertIn("__getitem__", diagnostics["text"])
        self.assertTrue(diagnostics["truncated"])
        self.assertNotIn("SECRET_ANSWER", json.dumps(observation))

    def test_invalid_threshold_is_rejected(self):
        observation = build_observation(paired_payload(), command_returncode=0)
        for value in (True, -1, float("nan"), float("inf")):
            with self.subTest(value=value), self.assertRaises(ValueError):
                evaluate_acceptance(observation, {"loss_abs": value})


if __name__ == "__main__":
    unittest.main()
