"""Layered evidence memory is explicit, auditable and absent from baselines."""

import copy
import json
import tempfile
import unittest
from pathlib import Path

from autofix.autonomous.agent import (
    AgentConfig, AutonomousAgent, BudgetExhausted, _json, _prepare_evidence_context,
)
from autofix.autonomous.tools import WorkspaceTools


def observed(index):
    return {"schema_version": "public-v1", "execution": {"status": "failed" if index < 2 else "passed"},
            "measurements": {"loss": index / 100, "norm": None if index == 0 else 1.7},
            "parameters": [{"name": f"layer_{i}.weight", "value": float(i) + (index if i == 173 else 0),
                            "status": "observed"} for i in range(500)]}


def apply_delta(value, operations):
    value = copy.deepcopy(value)
    for op in operations:
        path = op["path"]
        if not path:
            value = copy.deepcopy(op["value"])
            continue
        parts = [p.replace("~1", "/").replace("~0", "~") for p in path[1:].split("/")]
        target = value
        for part in parts[:-1]:
            target = target[int(part)] if isinstance(target, list) else target[part]
        key = int(parts[-1]) if isinstance(target, list) else parts[-1]
        if op["op"] == "remove":
            del target[key]
        else:
            target[key] = copy.deepcopy(op["value"])
    return value


def response(content="done"):
    return {"model": "test-actual-model", "choices": [{"message": {"role": "assistant", "content": content},
                                                        "finish_reason": "stop"}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5}}


def tool_message(ident, name, payload):
    return [{"role": "assistant", "content": "Inspecting the public evidence.", "tool_calls": [
        {"id": ident, "type": "function", "function": {"name": name, "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": ident, "content": _json(payload)}]


class EvidenceMemoryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.workspace = self.root / "workspace"
        self.workspace.mkdir()
        (self.workspace / "candidate.py").write_text("value = 1\n")
        (self.workspace / "source.py").write_text("value = 1\n")
        (self.workspace / "task.json").write_text('{}')

    def agent(self, *, max_chars=60000, method="layered", memory_policy="evidence", workflow_policy="auto", responses=None):
        self.requests = []
        replies = iter(responses or [response()])
        def client(request, timeout_seconds):
            self.requests.append(copy.deepcopy(request))
            return next(replies)
        return AutonomousAgent(WorkspaceTools(self.workspace, lambda _: {}), self.root / f"logs-{method}-{memory_policy}",
            config=AgentConfig(method=method, memory_policy=memory_policy, workflow_policy=workflow_policy,
                               max_context_chars=max_chars, compact_tool_chars=5000), client=client)

    def test_all_measurement_values_and_status_changes_are_exactly_reconstructable(self):
        originals = [observed(i) for i in range(9)]
        originals[3]["temporary"] = {"value": 34.75}
        originals[4]["parameters"][22]["value"] = -10.375
        messages = [{"role": "user", "content": "Controller observation:\n" + _json(value)} for value in originals]
        prepared, events = _prepare_evidence_context(messages, max_chars=60000, excerpt_chars=5000)
        self.assertLessEqual(len(_json(prepared)), 60000)
        self.assertTrue(any(e["strategy"] == "exact_observation_delta" for e in events))
        saved = {}
        for message, expected in zip(prepared, originals):
            item = json.loads(message["content"].split("\n", 1)[1])
            value = item.get("observation")
            if "json_patch" in item:
                value = apply_delta(saved[item["base_observation_id"]], item["json_patch"])
            saved[item["memory_observation_id"]] = value
            self.assertEqual(value, expected)

    def test_handoff_embedded_tools_compress_without_changing_diagnosis_or_edits(self):
        source = {"path": "target_library/example.py", "total_lines": 300,
                  "lines": [{"line": i + 1, "text": "value = " + repr("long source line " * 8)} for i in range(300)],
                  "next_line": None}
        diagnosis = {"role": "assistant", "content": _json({"diagnosis": {
            "category": "model-authored conclusion", "evidence": ["Actual source observation"],
            "hypotheses": [{"test": "check the public behavior", "status": "unresolved"}]}})}
        edit = {"role": "tool", "tool_call_id": "patch", "content": _json({"edits": [
            {"path": "candidate.py", "old": "1", "new": "2"}], "files": [{"path": "candidate.py"}]})}
        originals = tool_message("read1", "read", source) + [diagnosis, edit]
        messages = [{"role": "user", "content": _json({"verifier_record": item})} for item in originals]
        prepared, events = _prepare_evidence_context(messages, max_chars=12000, excerpt_chars=4000)
        self.assertLessEqual(len(_json(prepared)), 12000)
        unpacked = [json.loads(m["content"])["verifier_record"] for m in prepared]
        self.assertEqual(unpacked[0], originals[0])
        self.assertEqual(unpacked[-2], diagnosis)
        self.assertEqual(unpacked[-1], edit)
        excerpt = json.loads(unpacked[1]["content"])
        self.assertIn("memory_source_excerpt", excerpt)
        self.assertEqual(excerpt["total_lines"], 300)
        self.assertTrue(any(e["strategy"] == "source_list_excerpt" for e in events))

    def test_enabled_layered_memory_handles_public_observation_tags_and_keeps_raw_audit(self):
        messages = [{"role": "system", "content": "A role with a shared public task."}]
        for i in range(8):
            messages.append({"role": "user", "content": "Current evidence:\n<public_observation>\n"
                             + _json(observed(i)) + "\n</public_observation>"})
            messages.append({"role": "assistant", "content": f"Hypothesis {i}: decide the next test from the observed difference."})
        original = copy.deepcopy(messages)
        agent = self.agent()
        agent.complete(messages, stage="repair", attempt=2)
        self.assertEqual(messages, original)
        self.assertEqual(agent.calls, 1)
        sent = self.requests[0]["messages"]
        self.assertLessEqual(len(_json(sent)), 60000)
        self.assertEqual([m for m in sent if m["role"] == "assistant"],
                         [m for m in original if m["role"] == "assistant"])
        raw_events = list(agent.log_dir.glob("event_*_context_input.json"))
        self.assertEqual(len(raw_events), 1)
        self.assertEqual(json.loads(raw_events[0].read_text())["data"]["messages"], original)
        audit = json.loads((agent.log_dir / "call_0001_request.json").read_text())
        self.assertEqual(audit["messages"], sent)
        self.assertTrue(list(agent.log_dir.glob("event_*_evidence_memory.json")))
        self.assertEqual(agent.usage()["prompt_tokens"], 10)
        metadata = json.loads((agent.log_dir / "call_0001_metadata.json").read_text())
        protocol = json.loads((agent.log_dir / "protocol.json").read_text())
        self.assertEqual(metadata["memory_policy"], "evidence")
        self.assertTrue(metadata["compression_applied"])
        self.assertEqual(metadata["protocol_sha256"], protocol["protocol_sha256"])
        self.assertEqual(set(protocol["implementation_sha256"]), {"agent.py", "tools.py"})

    def test_baseline_default_preserves_full_messages_and_never_uses_our_memory(self):
        self.assertEqual(AgentConfig(method="single").memory_policy, "native")
        self.assertEqual(AgentConfig(method="direct").memory_policy, "native")
        for method in ("single", "direct"):
            with self.subTest(method=method):
                agent = self.agent(method=method, memory_policy="native")
                messages = [{"role": "system", "content": "Original baseline role."},
                            {"role": "user", "content": "<public_observation>" + _json(observed(0)) + "</public_observation>"}]
                agent.complete(messages, stage="baseline")
                self.assertEqual(self.requests[0]["messages"], messages)
                large = messages + [{"role": "user", "content": "Controller observation:\n" + _json(observed(i))} for i in range(1, 9)]
                with self.assertRaisesRegex(BudgetExhausted, "context_budget_exhausted"):
                    agent.complete(large, stage="baseline")
                self.assertEqual(agent.calls, 1)
                self.assertFalse(list(agent.log_dir.glob("event_*_evidence_memory.json")))
                self.assertFalse(list(agent.log_dir.glob("event_*_context_compaction.json")))

    def test_evidence_policy_cannot_be_enabled_for_other_methods(self):
        for method in ("single", "direct"):
            with self.subTest(method=method), self.assertRaisesRegex(ValueError, "layered method only"):
                AgentConfig(method=method, memory_policy="evidence")

    def test_ours_memory_ablation_changes_no_budget_or_role_prompt(self):
        messages = [{"role": "user", "content": "Controller observation:\n" + _json(observed(i))} for i in range(8)]
        native = self.agent(memory_policy="native")
        with self.assertRaisesRegex(BudgetExhausted, "context_budget_exhausted"):
            native.complete(messages, stage="repair")
        evidence = self.agent(memory_policy="evidence")
        evidence.complete(messages, stage="repair")
        fields = ("max_calls", "max_output_tokens", "max_seconds", "per_call_output_tokens",
                  "max_context_chars", "diagnosis_calls_per_stage", "repair_calls_per_stage")
        self.assertEqual([getattr(native.config, f) for f in fields], [getattr(evidence.config, f) for f in fields])
        self.assertEqual(native.history, evidence.history)
        self.assertEqual(native.calls, 0)
        self.assertEqual(evidence.calls, 1)
        self.assertNotEqual(native.protocol_sha256, evidence.protocol_sha256)

    def test_legacy_replays_v1_stage_compaction_without_new_complete_policy(self):
        final = _json({"diagnosis": {"category": "undetermined", "locations": [],
                                    "evidence": ["Prior tool observation"], "uncertainty": "Unresolved"},
                       "summary": "Preserved v1 flow."})
        agent = self.agent(max_chars=12000, memory_policy="legacy", responses=[response(final)])
        agent.history.append({"role": "tool", "tool_call_id": "old_read", "content": "HEAD" + "x" * 25000 + "TAIL"})
        agent.history.extend({"role": "user", "content": "Recent observation"} for _ in range(4))
        agent.tool_records["old_read"] = {"name": "read", "event": "raw_read.json", "compacted": False}
        result = agent.diagnose({"measurement": 1.0})
        self.assertEqual(result.status, "completed")
        self.assertTrue(list(agent.log_dir.glob("event_*_context_compaction.json")))
        self.assertFalse(list(agent.log_dir.glob("event_*_evidence_memory.json")))
        self.assertEqual(json.loads((agent.log_dir / "call_0001_metadata.json").read_text())["memory_policy"], "legacy")

    def test_large_source_blocks_are_explicit_excerpts_and_assistant_code_is_untouched(self):
        code = "def public_function():\n" + "    value = 'source detail' * 20\n" * 1500
        decision = {"role": "assistant", "content": "Keep the patch and hypothesis exactly.\n```python\nanswer = 3\n```"}
        messages = [{"role": "user", "content": "Source module:\n```python\n" + code + "\n```"}, decision]
        prepared, events = _prepare_evidence_context(messages, max_chars=10000, excerpt_chars=5000)
        self.assertLessEqual(len(_json(prepared)), 10000)
        self.assertIn("MEMORY EXCERPT", prepared[0]["content"])
        self.assertEqual(prepared[1], decision)
        self.assertTrue(any(e["strategy"] == "source_excerpt" for e in events))

    def test_unique_numeric_evidence_exceeding_limit_stops_with_full_raw_record(self):
        huge = {"measurements": [{"index": i, "value": i + 0.12345} for i in range(3000)]}
        messages = tool_message("test1", "run_test", huge)
        agent = self.agent(max_chars=15000)
        with self.assertRaisesRegex(BudgetExhausted, "context_budget_exhausted"):
            agent.complete(messages)
        self.assertEqual(agent.calls, 0)
        self.assertEqual(self.requests, [])
        raw = list(agent.log_dir.glob("event_*_context_input.json"))[0]
        self.assertEqual(json.loads(raw.read_text())["data"]["messages"], messages)
        self.assertTrue(list(agent.log_dir.glob("event_*_context_budget_exhausted.json")))

    def test_identical_source_read_uses_explicit_reference_but_new_source_is_preserved(self):
        source = {"path": "candidate.py", "lines": [{"line": i, "text": "public value = 1"} for i in range(160)], "next_line": None}
        changed = copy.deepcopy(source)
        changed["lines"][47]["text"] = "public value = 2"
        messages = tool_message("r1", "read", source) + tool_message("r2", "read", source) + tool_message("r3", "read", changed)
        prepared, _ = _prepare_evidence_context(messages, max_chars=16000, excerpt_chars=10000)
        original_read = json.loads(prepared[1]["content"])
        repeated_read = json.loads(prepared[3]["content"])
        changed_read = json.loads(prepared[5]["content"])
        self.assertEqual(repeated_read["memory_evidence_reference"], original_read["memory_evidence_id"])
        self.assertEqual(changed_read["lines"][47]["text"], "public value = 2")

    def test_enabled_layered_stage_compacts_before_declaring_context_exhaustion(self):
        final = _json({"diagnosis": {"category": "undetermined", "locations": [],
                                    "evidence": ["Inspected public source"], "uncertainty": "More tests needed"},
                       "summary": "Recorded actual investigation."})
        agent = self.agent(max_chars=15000, method="layered", workflow_policy="standard", responses=[response(final)])
        source = {"path": "candidate.py", "lines": [{"line": i, "text": "value = 'long source details' " * 6} for i in range(250)]}
        agent.history.extend(tool_message("earlier_read", "read", source))
        agent.last_diagnosis = {"category": "undetermined", "evidence": ["Actual source investigation"]}
        original = copy.deepcopy(agent.history)
        result = agent.repair({"measurements": {"loss": 0.4}})
        self.assertEqual(result.status, "completed")
        self.assertEqual(agent.verifier_history, original)
        self.assertEqual(agent.calls, 1)
        self.assertLessEqual(len(_json(self.requests[0]["messages"])), 15000)
        self.assertTrue(any("memory_source_excerpt" in m.get("content", "") for m in self.requests[0]["messages"]))


if __name__ == "__main__":
    unittest.main()
