"""Recorded repository acceptance predicates."""
import numpy as np

def protocol():
    return {
      'task_kind':'framework_migration','source_framework':'PyTorch','target_framework':'native MindSpore 2.7.2 (CPU, PyNative)',
      'source_entry':'source/project.py','target_entry':'target/project.py','source_commit':'749689e352290616e69d9b3e243af36936328964',
      'scope':'Complete repository: project.py, every step_by_step_code_blocks Python file, executable notebook code, requirements and README. Preserve original file paths and all implemented behavior; shared helpers may replace duplicated code.',
      'inputs':'The evaluator replaces the external Alpha Vantage response with 180 fixed synthetic prices. No external API key is needed for tests. Preserve download_data parsing, normalization, window size, chronological split, model architecture, optimizer, learning-rate schedule, training/validation, forecasts and five plots.',
      'source_roots':['source/'],'editable_roots':['target/','scratch_tests/'],
      'runtime':'Use native MindSpore for forward, autodiff and parameter updates. NumPy is allowed for preprocessing and visualization only. Do not import PyTorch, target_library, jax_bridge or JAX in target code. Importing project must not train or fetch data; executing it must call main().',
      'public_interfaces':{
        'LSTMModel':'Retain original constructor signature and architecture as mindspore.nn.Cell. Source parameter shapes are preserved. parameter_map.json maps every original named parameter to exactly one target parameters_and_names() key.',
        'Normalizer, prepare_data_x, prepare_data_y, TimeSeriesDataset, download_data':'Preserve source behavior and public signatures.',
        'make_optimizer(model)':'Return the native target optimizer configured according to the source, initialized with the source initial learning rate. Used by both main training and the probe.',
        'train_batch(model, optimizer, x, y)':'Execute one real training batch using mindspore.value_and_grad and the supplied optimizer. Inputs are MindSpore float32 tensors. The evaluator independently observes native autodiff, parameters, predictions and gradients. This same helper must be used by run_epoch/main.',
        'learning_rate_for_epoch(epoch)':'Return the source learning rate for zero-based epoch. This schedule must be used by the real workflow.',
        'main()':'Run the original complete workflow with default config (100 epochs, dropout 0.2), print progress and generate all five figures. Return final locals as a dict including config, model, prediction (NumPy array), predicted_train and predicted_val. CLI calls main().',
        'parameter_map.json':'Object mapping source named parameter strings to native target parameter names. No omitted, extra, merged, or duplicated parameters.',
        'notebook':'Preserve the instructional progression and runnable functionality using MindSpore. Clear old execution outputs. Shared project helpers may be imported; do not leave PyTorch code in cells.'},
      'acceptance':{'preprocessing_max_abs':1e-9,'prediction_max_abs':1e-4,'loss_abs':.02,'gradient_vector_l2':.05,'parameter_update_relative_l2':.03,
        'numeric_probe':'Three sequential Adam steps from identical source-derived parameters, dropout=0, batch [4,20,1], three validation seeds. All steps must pass. Learning-rate boundaries at epochs 0,39,40,79,80.',
        'workflow':'Default 100 epochs, 128 training and 32 validation predictions, one finite next-day forecast, five plots, observed native gradients during at least 200 training batches. This is stochastic execution coverage, not cross-framework identical Dropout-mask equivalence.',
        'coverage':'All original code-bearing files present and syntactically valid; no forbidden target framework imports or unconverted notebook cells. Instructional snippets remain part of the repository; their standalone execution is not assumed by the original repo.'},
      'tools':{'paired':'Preprocessing and training-equivalence probe on the public seed.','workflow':'Full default 100-epoch workflow with local market-data fixture.','public':'Both paired and workflow tests.'},
      'integrity':'Do not modify source/, task.json, evaluator instrumentation or hard-code test outputs. Investigate and repair autonomously from source code, public contract and observed tests. No known faults or repair locations are supplied.'}

def compare(reference,target,request):
    def arr(x):return np.asarray(x,dtype=float)
    measures={};checks={}
    for name,value in reference['preprocessing'].items():
        a,b=arr(value),arr(target['preprocessing'][name])
        diff=float(np.max(np.abs(a-b))) if a.shape==b.shape else 1e100
        measures['preprocessing_'+name]=diff;checks['preprocessing_'+name]=diff<=1e-9
    initial=np.concatenate([arr(request['initial_state'][k]).ravel() for k in sorted(request['initial_state'])])
    for i,(source,dest) in enumerate(zip(reference['steps'],target['steps']),1):
        pred=float(np.max(np.abs(arr(source['prediction'])-arr(dest['prediction']))))
        loss=abs(source['loss']-dest['loss'])
        grad=np.concatenate([(arr(source['gradients'][k])-arr(dest['gradients'][k])).ravel() for k in sorted(source['gradients'])])
        state=lambda row:np.concatenate([arr(row['state'][k]).ravel() for k in sorted(row['state'])])
        source_state,target_state=state(source),state(dest)
        update=float(np.linalg.norm(source_state-target_state)/max(float(np.linalg.norm(source_state-initial)),1e-12))
        values={'prediction_max_abs':pred,'loss_abs':loss,'gradient_vector_l2':float(np.linalg.norm(grad)),'parameter_update_relative_l2':update}
        for k,v in values.items():
            measures[f'step_{i}_{k}']=v;checks[f'step_{i}_{k}']=bool(np.isfinite(v) and v<=protocol()['acceptance'][k])
        checks[f'step_{i}_native_autodiff']=dest.get('native_gradient_tensors',0)==len(request['initial_state'])
    checks['three_steps']=len(target['steps'])==3
    checks['learning_rate_boundaries']=bool(np.allclose(target['learning_rates'],[.01,.01,.001,.001,.0001],rtol=1e-6,atol=1e-10))
    checks['parameter_count']=target['parameter_count']==17025
    return {'accepted':all(checks.values()),'checks':checks,'measurements':measures}
