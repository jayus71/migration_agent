"""Execute translated training operations; never load reference outputs or an oracle."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import sys

if os.getenv('PAIR_TORCH_SITE'):
    sys.path.insert(0, os.environ['PAIR_TORCH_SITE'])
import numpy as np
import torch


def execute(candidate, fixture, output):
    torch.set_num_threads(2)
    torch.manual_seed(fixture['seed'])
    spec = importlib.util.spec_from_file_location('translated_candidate', candidate)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    training = module.build_training(fixture['context'])
    parameters = list(training.parameters())
    buffers = list(training.buffers())
    data = np.load(Path(fixture['_root'])/'inputs.npz', allow_pickle=False)
    expected = fixture['context']['parameters']
    state_expected = fixture['context']['buffers']
    if len(parameters) != len(expected) or len(buffers) != len(state_expected):
        raise ValueError('Parameter/buffer count differs from the public interface')
    with torch.no_grad():
        for i, (value, desc) in enumerate(zip(parameters, expected)):
            if list(value.shape) != desc['shape'] or not value.requires_grad:
                raise ValueError(f'Parameter shape/gradient flag mismatch at {i}')
            value.copy_(torch.from_numpy(data[f'p_{i}'].copy()))
        for i, (value, desc) in enumerate(zip(buffers, state_expected)):
            if list(value.shape) != desc['shape']:
                raise ValueError(f'Buffer shape mismatch at {i}')
            value.copy_(torch.from_numpy(data[f'b_{i}'].copy()))
    arrays = {}
    records = []
    def save(value, key):
        if not isinstance(value, torch.Tensor):
            raise TypeError(f'{key} must be a tensor')
        arrays[key] = value.detach().cpu().numpy().copy()
        return key
    for i, batch in enumerate(fixture['batches']):
        inputs = [torch.from_numpy(data[k].copy()) for k in batch['inputs']]
        labels = [torch.from_numpy(data[k].copy()) for k in batch['labels']]
        training.zero_grad()
        if batch.get('forward_seed') is not None:
            torch.manual_seed(batch['forward_seed'])
        values = training.forward(inputs, labels)
        if not isinstance(values, (tuple, list)):
            raise TypeError('forward must return a list of output tensors')
        loss = training.loss(values, labels)
        training.backward(loss)
        record = dict(outputs=[save(v, f's{i}_out{j}') for j,v in enumerate(values)],
                      loss=save(loss, f's{i}_loss'),
                      gradients=[save(p.grad, f's{i}_g{j}') for j,p in enumerate(parameters)])
        # Snapshot actual candidate operations; the harness supplies no optimizer.
        old = [p.detach().clone() for p in parameters]
        training.step()
        record['updates'] = [save(p-v, f's{i}_u{j}') for j,(p,v) in enumerate(zip(parameters,old))]
        record['parameters'] = [save(p, f's{i}_p{j}') for j,p in enumerate(parameters)]
        record['buffers'] = [save(b, f's{i}_b{j}') for j,b in enumerate(buffers)]
        state = training.optimizer_state()
        record['optimizer'] = []
        for j, row in enumerate(state):
            entry = {'updates': int(row['updates'])}
            for key in ('means', 'variances'):
                if key in row: entry[key] = save(row[key], f's{i}_opt{j}_{key}')
            record['optimizer'].append(entry)
        records.append(record)
    output.mkdir(parents=True,exist_ok=True)
    np.savez(output/'observed.npz', **arrays)
    (output/'observed.json').write_text(json.dumps({'steps':records,'torch':torch.__version__}))


if __name__ == '__main__':
    p=argparse.ArgumentParser()
    p.add_argument('--candidate',type=Path,required=True)
    p.add_argument('--fixture',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    a=p.parse_args()
    f=json.loads(a.fixture.read_text());f['_root']=str(a.fixture.parent)
    execute(a.candidate.resolve(),f,a.output)
