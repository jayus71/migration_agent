"""Recorded JAX loss, gradient-norm and update differences."""
import math

def finite(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)

def measurements(reference, target):
    values = {"loss_abs": None, "grad_norm_abs": None, "param_update_rel_l2": None}
    if reference.get("status") != "ok" or target.get("status") != "ok":
        return values
    if finite(reference.get("loss")) and finite(target.get("loss")):
        values["loss_abs"] = abs(reference["loss"] - target["loss"])
    if finite(reference.get("grad_norm")) and finite(target.get("grad_norm")):
        values["grad_norm_abs"] = abs(reference["grad_norm"] - target["grad_norm"])
    left, right = reference.get("update_by_name", {}), target.get("update_by_name", {})
    if left and left.keys() == right.keys() and all(len(left[k]) == len(right[k]) for k in left):
        a = [v for k in sorted(left) for v in left[k]]
        b = [v for k in sorted(right) for v in right[k]]
        if all(finite(v) for v in a + b):
            values["param_update_rel_l2"] = math.sqrt(sum((x-y)**2 for x,y in zip(a,b))) / max(math.sqrt(sum(x*x for x in a)), 1e-12)
    return values
