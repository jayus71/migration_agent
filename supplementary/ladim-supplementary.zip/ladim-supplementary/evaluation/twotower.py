"""Recorded repository acceptance predicates."""
import numpy as np

THRESHOLDS={'embedding_max_abs':1e-4,'loss_atol':.002,'loss_rtol':.0001,'gradient_atol':.0001,'gradient_rtol':.005,'update_relative_l2':.03}

def compare(reference,target,request):
    checks={};measurements={};case_status={}
    def arrays(label,left,right,atol,rtol=0.):
        a,b=np.asarray(left,dtype=float),np.asarray(right,dtype=float)
        ok=a.shape==b.shape and np.isfinite(b).all() and np.allclose(a,b,atol=atol,rtol=rtol)
        checks[label]=bool(ok)
        measurements[label]=float(np.max(np.abs(a-b))) if a.shape==b.shape and a.size else (0. if a.shape==b.shape else 1e100)
    for name,src in reference.items():
        dst=target.get(name,{})
        if dst.get('status')=='error' or 'inference' not in dst or 'training' not in dst:
            checks[name+'_execution']=False;case_status[name]=dst;continue
        case_status[name]={k:{'source':src[k]['status'],'target':dst[k]['status']} for k in ('inference','training')}
        for kind in ('inference','training'):
            s,t=src[kind],dst[kind]
            checks[name+'_'+kind+'_status']=s['status']==t['status']
            if s['status']=='raises':checks[name+'_'+kind+'_exception']=s.get('error_type')==t.get('error_type')
        if src['inference']['status']=='ok' and dst['inference']['status']=='ok':arrays(name+'_retrieval',src['inference']['recommendations'],dst['inference']['recommendations'],0.)
        if src['training']['status']!='ok' or dst['training']['status']!='ok':continue
        s_steps=src['training']['steps'];t_steps=dst['training']['steps'];checks[name+'_three_steps']=len(t_steps)==3
        keys=sorted(request['cases'][name]['initial_state'])
        vector=lambda values:np.concatenate([np.asarray(values[k],dtype=float).ravel() for k in keys])
        s_before=vector(request['cases'][name]['initial_state']);t_before=s_before.copy()
        for i,(s,t) in enumerate(zip(s_steps,t_steps),1):
            prefix=name+'_step'+str(i)
            for value in ('user_embedding','item_embedding'):arrays(prefix+'_'+value,s[value],t[value],THRESHOLDS['embedding_max_abs'])
            for value in ('loss','epoch_loss'):arrays(prefix+'_'+value,s[value],t[value],THRESHOLDS['loss_atol'],THRESHOLDS['loss_rtol'])
            sg,tg=vector(s['gradients']),vector(t['gradients'])
            arrays(prefix+'_gradient',sg,tg,THRESHOLDS['gradient_atol'],THRESHOLDS['gradient_rtol'])
            sn,tn=vector(s['state']),vector(t['state'])
            delta=float(np.linalg.norm((sn-s_before)-(tn-t_before))/max(np.linalg.norm(sn-s_before),1e-12))
            checks[prefix+'_update']=bool(np.isfinite(delta) and delta<=THRESHOLDS['update_relative_l2']);measurements[prefix+'_update_relative_l2']=delta
            s_before,t_before=sn,tn
        checks[name+'_native_autodiff']=dst['training'].get('native_autodiff_calls',0)>=3
    return {'accepted':all(checks.values()),'checks':checks,'measurements':measurements,'case_status':case_status}
