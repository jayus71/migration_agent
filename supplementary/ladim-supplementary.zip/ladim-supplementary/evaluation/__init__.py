"""Evaluation utilities."""
