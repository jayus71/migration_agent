"""Final repository repair schedule over externally prepared inputs.

Supply evaluator_factory(repository, workspace, evidence) returning an object
with tool(request) and final(), and adapter_factory(method, agent) for baselines.
    The prepared root contains source/, task.json, manifest.json, freeze.json
    and translation/. The caller validates its frozen external input manifest.
"""
from dataclasses import asdict, replace
import hashlib
import json
import math
import os
from pathlib import Path
import shutil
import time
import traceback
from autofix.autonomous.agent import AgentConfig, AutonomousAgent
from autofix.autonomous.tools import WorkspaceTools
from autofix.autonomous.repository import RepositoryAgent, RepositoryTools

BUDGET = dict(model='deepseek-v4-flash', max_calls=80, max_output_tokens=480000,
              max_seconds=3600, per_call_output_tokens=32768)

def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')

def read(path):
    return json.loads(path.read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def hashes(root):
    return {p.relative_to(root).as_posix(): digest(p) for p in sorted(root.rglob('*'))
            if p.is_file() and not any(x.startswith('.') or x == '__pycache__' for x in p.relative_to(root).parts)}

def configuration(method):
    return AgentConfig(**BUDGET, method='layered' if method == 'ladim' else 'single',
        memory_policy='evidence' if method == 'ladim' else 'native',
        workflow_policy='progress_loop' if method == 'ladim' else 'standard',
        diagnosis_policy='evidence', diagnosis_calls_per_stage=6, repair_calls_per_stage=18)

def named_tests(repository):
    return ('paired', 'workflow', 'entrypoints', 'coverage', 'public') if repository == 'timeseries' else ('base', 'paired', 'tests', 'workflow', 'coverage', 'public')

def make_workspace(root, folder, initial):
    ws = folder / 'workspace'
    ws.mkdir(parents=True, exist_ok=False)
    shutil.copytree(root / 'source', ws / 'source')
    shutil.copytree(initial, ws / 'target', ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
    shutil.copy2(root / 'task.json', ws / 'task.json')
    (ws / 'scratch_tests').mkdir()
    return ws

def run(repository, method, root, evaluator_factory, adapter_factory=None):
    root = Path(root).resolve()
    translation = read(root / 'translation/result.json')
    expected_initial = translation.get('target_hashes', translation.get('original_record', {}).get('files'))
    assert expected_initial and hashes(root / 'translation/target') == expected_initial, 'Shared initial translation changed'
    folder = root / 'conditions' / method
    folder.mkdir(parents=True, exist_ok=False)
    ws = make_workspace(root, folder, root / 'translation/target')
    assert hashes(ws / 'target') == expected_initial
    ev = evaluator_factory(repository, ws, folder / 'evidence')
    ours = method == 'ladim'
    tool_args = dict(named_tests=named_tests(repository), validate_syntax=ours)
    if ours:
        tool_args['state_path'] = folder / 'evidence/repository_state.json'
    tools = (RepositoryTools if ours else WorkspaceTools)(ws, ev.tool, **tool_args)
    agent = (RepositoryAgent if ours else AutonomousAgent)(tools, folder / 'evidence/agent', config=configuration(method))
    adapter = None if ours else adapter_factory(method, agent)
    if ours:
        agent.set_generation_state(translation.get('file_states', {}))
    save(folder / 'protocol.json', {'config': asdict(agent.config), 'freeze_sha256': digest(root / 'freeze.json'),
        'initial_target_hashes': hashes(ws / 'target'), 'translation_result_sha256': digest(root / 'translation/result.json'),
        'translation_usage': translation['usage'], 'pid': os.getpid()})
    result = {'status': 'running', 'repository': repository, 'method': method, 'accepted': False, 'attempts': []}
    save(folder / 'result.json', result)
    original_snapshot = agent._snapshot
    def progress_snapshot():
        original_snapshot()
        for label, reached in [('calls40', agent.calls >= 40), ('output240000', agent.output_tokens >= 240000)]:
            checkpoint = folder / 'progress' / label
            if reached and not checkpoint.exists():
                checkpoint.mkdir(parents=True)
                shutil.copytree(ws / 'target', checkpoint / 'target', ignore=shutil.ignore_patterns('__pycache__', '.pytest_cache'))
                save(checkpoint / 'state.json', {'calls': agent.calls, 'usage': agent.usage(), 'target_hashes': hashes(ws / 'target'),
                    'measurement_status': 'candidate snapshot; acceptance measured at normal external submissions'})
    agent._snapshot = progress_snapshot
    try:
        current = ev.final()
        result['initial'] = current
        save(folder / 'result.json', result)
        # Evaluation time is included in the common lifetime clock.
        if not current['accepted']:
            if ours:
                base_config = agent.config
                agent.config = replace(base_config, max_output_tokens=min(64000, base_config.max_output_tokens))
                result['diagnosis'] = asdict(agent.diagnose(current['observation']))
                agent.config = base_config
            else:
                ready = adapter.initialize(current['observation'])
                result['initialization'] = asdict(ready)
                if ready.status != 'ready':
                    raise RuntimeError('Baseline initialization: ' + ready.status)
            for attempt in range(1, 5):
                if agent._budget_status():
                    break
                if ours:
                    base_config = agent.config
                    submissions_left = 5 - attempt
                    calls = math.ceil((base_config.max_calls - agent.calls) / submissions_left)
                    if attempt == 1:
                        calls = min(16, calls)
                    output = math.ceil((base_config.max_output_tokens - agent.output_tokens) / submissions_left)
                    agent.config = replace(base_config, repair_calls_per_stage=max(2, calls), max_output_tokens=agent.output_tokens + output)
                    stage = agent.repair(current['observation'], attempt)
                    agent.config = base_config
                else:
                    stage = adapter.repair(current['observation'], attempt)
                current = ev.final()
                result['attempts'].append({'attempt': attempt, 'stage': asdict(stage), 'evaluation': current,
                    'calls': agent.calls, 'usage': agent.usage()})
                result.update(calls=agent.calls, usage=agent.usage(), accepted=current['accepted'])
                save(folder / 'result.json', result)
                if current['accepted'] or agent._budget_status() or stage.status in ('api_error', 'infrastructure_error', 'error', 'not_applicable'):
                    break
        result.update(status='completed', accepted=current['accepted'], final=current, stop_reason=agent._budget_status())
    except Exception as exc:
        result.update(status='infrastructure_error', error=str(exc), traceback=traceback.format_exc())
    finally:
        if adapter and hasattr(adapter, 'close'):
            adapter.close()
        result.update(calls=agent.calls, usage=agent.usage(), final_target_hashes=hashes(ws / 'target'),
            source_unchanged=hashes(ws / 'source') == read(root / 'manifest.json')['source_hashes'],
            task_unchanged=digest(ws / 'task.json') == read(root / 'manifest.json')['task_sha256'],
            translation_usage=translation['usage'], end_to_end_tokens=agent.usage()['total_tokens'] + translation['usage']['total_tokens'])
        save(folder / 'result.json', result)
    print(json.dumps({k: result.get(k) for k in ('repository', 'method', 'status', 'accepted', 'calls', 'usage', 'error')}), flush=True)
