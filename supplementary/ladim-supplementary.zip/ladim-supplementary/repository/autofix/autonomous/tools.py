"""Small, shared tools for an isolated repair workspace.

The runner callback must execute candidate code in the controller's sandbox.
This module deliberately provides no shell, subprocess, network or import tool.
Only the public task and source, candidate, library Python files and scratch
tests are visible; evaluator artifacts and repository metadata are not exposed.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
from typing import Any, Callable, Iterable


class ToolError(ValueError):
    """An invalid or disallowed model tool request."""


class WorkspaceTools:
    def __init__(
        self,
        root: str | Path,
        run_test: Callable[[dict[str, Any]], Any],
        *,
        named_tests: Iterable[str] = ("paired", "public"),
        max_file_bytes: int = 2_000_000,
        max_test_seconds: float = 180.0,
        validate_syntax: bool = False,
    ) -> None:
        self.root = Path(root).resolve(strict=True)
        self.runner = run_test
        self.named_tests = frozenset(named_tests)
        if not self.named_tests or any(
            not isinstance(name, str) or not name.replace("_", "").isalnum()
            for name in self.named_tests
        ):
            raise ValueError("named_tests must contain simple test names")
        self.max_file_bytes = max_file_bytes
        self.max_test_seconds = max_test_seconds
        self.validate_syntax = validate_syntax
        self.edit_records: list[dict[str, Any]] = []

    @staticmethod
    def _visible(path: str) -> bool:
        parts = PurePosixPath(path).parts
        return path in {"source.py", "candidate.py", "task.json"} or (
            len(parts) > 1
            and ((parts[0] in {"target_library", "scratch_tests"} and path.endswith(".py")) or (parts[0] in {"source", "target"} and (PurePosixPath(path).suffix in {".py", ".json", ".md", ".txt", ".ipynb", ".yaml", ".yml", ".toml"} or parts[-1] == "LICENSE")))
        )

    def _path(self, value: Any, *, write: bool = False) -> Path:
        if not isinstance(value, str) or not value or "\\" in value or ":" in value:
            raise ToolError("Use a relative POSIX file path")
        parts = PurePosixPath(value).parts
        if value.startswith("/") or any(p in {"..", "."} or p.startswith(".") for p in parts):
            raise ToolError("Absolute, hidden and traversal paths are forbidden")
        if str(PurePosixPath(value)) != value or not self._visible(value):
            raise ToolError("File is outside the public workspace allowlist")
        if write and (value in {"source.py", "task.json"} or parts[0] == "source"):
            raise ToolError("The source and task specification are read-only")
        candidate = self.root / value
        current = self.root
        for part in parts:
            current = current / part
            if current.is_symlink():
                raise ToolError("Symbolic links are forbidden")
        if not candidate.resolve().is_relative_to(self.root):
            raise ToolError("Resolved file is outside the workspace")
        if candidate.exists():
            if not candidate.is_file():
                raise ToolError("Expected a regular file")
            if candidate.stat().st_nlink != 1:
                raise ToolError("Hard-linked files are forbidden")
            if candidate.stat().st_size > self.max_file_bytes:
                raise ToolError("File exceeds the public file size limit")
        return candidate

    def _files(self) -> list[str]:
        files = [name for name in ("source.py", "candidate.py", "task.json") if (self.root / name).exists()]
        for directory in ("target_library", "scratch_tests", "source", "target"):
            start = self.root / directory
            if not start.is_dir() or start.is_symlink():
                continue
            for base, directories, names in os.walk(start, followlinks=False):
                directories[:] = sorted(
                    name for name in directories
                    if not name.startswith(".") and not (Path(base) / name).is_symlink()
                )
                files.extend(
                    (Path(base) / name).relative_to(self.root).as_posix()
                    for name in sorted(names)
                    if (name.endswith(".py") or directory in {"source", "target"}) and not name.startswith(".")
                )
        visible = []
        for name in sorted(files):
            try:
                self._path(name)
            except ToolError:
                continue
            visible.append(name)
        return visible

    def schemas(self, *, readonly: bool = False) -> list[dict[str, Any]]:
        definitions = [
            ("list", "List public files with pagination; next_offset is null at the end.", {
                "prefix": {"type": "string"}, "offset": {"type": "integer", "minimum": 0},
                "limit": {"type": "integer", "minimum": 1, "maximum": 500},
            }, []),
            ("read", "Read a public UTF-8 file by one-based line range. Read task.json for the public contract; source/ contains the immutable full repository when provided; source.py may also be available.", {
                "path": {"type": "string"}, "start_line": {"type": "integer", "minimum": 1},
                "max_lines": {"type": "integer", "minimum": 1, "maximum": 400},
            }, ["path"]),
            ("search", "Search a literal string in public files; use offset to retrieve subsequent matches.", {
                "query": {"type": "string"}, "prefix": {"type": "string"},
                "offset": {"type": "integer", "minimum": 0},
                "limit": {"type": "integer", "minimum": 1, "maximum": 200},
            }, ["query"]),
            ("run_test", "Run a named public test or a scratch_tests/*.py test through the isolated runner. Available names: " + ", ".join(sorted(self.named_tests)) + ". No shell commands.", {
                "test": {"type": "string"}, "timeout_seconds": {"type": "number", "exclusiveMinimum": 0},
            }, ["test"]),
        ]
        edit_description = (
            "Apply exact replacements transactionally across files. old must occur exactly once. "
            "Use old='' only to create a new Python file. "
            + ("Diagnosis stage: only scratch_tests/**/*.py may be created or edited; candidate and library are immutable."
               if readonly else
               "candidate.py, target_library/**/*.py, target/**/* and scratch_tests/**/*.py are repairable. New files may be created under target/, target_library/ or scratch_tests/. source/ and task.json are immutable. Source and task are immutable.")
        )
        if self.validate_syntax:
            edit_description += " All edited Python files must compile; a syntax error rejects the entire edit transaction and reports its public location."
        definitions.append(("edit", edit_description, {
                "edits": {"type": "array", "minItems": 1, "maxItems": 30, "items": {
                    "type": "object", "properties": {
                        "path": {"type": "string"}, "old": {"type": "string"}, "new": {"type": "string"},
                    }, "required": ["path", "old", "new"], "additionalProperties": False,
                }},
            }, ["edits"]))
        return [{"type": "function", "function": {
            "name": name, "description": description,
            "parameters": {"type": "object", "properties": properties,
                           "required": required, "additionalProperties": False},
        }} for name, description, properties, required in definitions]

    @staticmethod
    def _integer(args: dict[str, Any], key: str, default: int, low: int, high: int) -> int:
        value = args.get(key, default)
        if type(value) is not int or not low <= value <= high:
            raise ToolError(f"{key} must be an integer between {low} and {high}")
        return value

    def execute(
        self, name: str, arguments: dict[str, Any], *, readonly: bool = False,
        remaining_seconds: float | None = None,
    ) -> Any:
        if not isinstance(arguments, dict):
            raise ToolError("Tool arguments must be an object")
        allowed = {item["function"]["name"]: item["function"]["parameters"] for item in self.schemas(readonly=readonly)}
        if name not in allowed:
            raise ToolError("Tool is unavailable in this stage")
        schema = allowed[name]
        if set(arguments) - set(schema["properties"]) or set(schema["required"]) - set(arguments):
            raise ToolError("Unknown or missing tool arguments")
        if name == "edit":
            return self._edit(arguments["edits"], readonly=readonly)
        if name == "run_test":
            test = arguments["test"]
            if not isinstance(test, str):
                raise ToolError("test must be a named test or a scratch test path")
            if test not in self.named_tests:
                if not test.startswith("scratch_tests/") or not self._path(test).is_file():
                    raise ToolError("Unknown test; shell commands are forbidden")
            timeout = arguments.get("timeout_seconds", self.max_test_seconds)
            if type(timeout) not in (int, float) or not 0 < timeout < float("inf"):
                raise ToolError("timeout_seconds must be positive and finite")
            timeout = min(timeout, self.max_test_seconds)
            if remaining_seconds is not None:
                timeout = min(timeout, remaining_seconds)
            if timeout <= 0:
                raise ToolError("Run time budget exhausted")
            # The controller owns isolation, environment scrubbing and hard timeout enforcement.
            return self.runner({"test": test, "timeout_seconds": timeout})
        if name == "read":
            path = self._path(arguments["path"])
            if not path.is_file():
                raise ToolError("File does not exist")
            lines = path.read_text(encoding="utf-8").splitlines()
            start = self._integer(arguments, "start_line", 1, 1, 10_000_000)
            count = self._integer(arguments, "max_lines", 200, 1, 400)
            end = min(len(lines), start - 1 + count)
            return {"path": arguments["path"], "start_line": start, "total_lines": len(lines),
                    "lines": [{"line": i + 1, "text": lines[i]} for i in range(start - 1, end)],
                    "next_line": end + 1 if end < len(lines) else None}
        prefix = arguments.get("prefix", "")
        if not isinstance(prefix, str) or ".." in prefix or "\\" in prefix or prefix.startswith("/"):
            raise ToolError("prefix must be a relative public path prefix")
        offset = self._integer(arguments, "offset", 0, 0, 10_000_000)
        limit = self._integer(arguments, "limit", 100, 1, 500 if name == "list" else 200)
        paths = [path for path in self._files() if path.startswith(prefix)]
        if name == "list":
            values: list[Any] = paths
        else:
            query = arguments["query"]
            if not isinstance(query, str) or not query or len(query) > 2000:
                raise ToolError("query must be a nonempty literal string of at most 2000 characters")
            values = []
            for path in paths:
                for index, line in enumerate(self._path(path).read_text(encoding="utf-8").splitlines(), 1):
                    if query in line:
                        values.append({"path": path, "line": index, "text": line})
        return {"files" if name == "list" else "matches": values[offset:offset + limit],
                "total": len(values), "next_offset": offset + limit if offset + limit < len(values) else None}

    def _edit(self, edits: Any, *, readonly: bool = False) -> dict[str, Any]:
        if not isinstance(edits, list) or not 1 <= len(edits) <= 30:
            raise ToolError("edits must contain between 1 and 30 replacements")
        original: dict[Path, str | None] = {}
        staged: dict[Path, str] = {}
        for edit in edits:
            if not isinstance(edit, dict) or set(edit) != {"path", "old", "new"}:
                raise ToolError("Every edit requires only path, old and new")
            path = self._path(edit["path"], write=True)
            if readonly and not edit["path"].startswith("scratch_tests/"):
                raise ToolError("Diagnosis may edit only scratch_tests; candidate and library are immutable")
            old, new = edit["old"], edit["new"]
            if not isinstance(old, str) or not isinstance(new, str):
                raise ToolError("old and new must be strings")
            if path not in original:
                original[path] = path.read_text(encoding="utf-8") if path.exists() else None
            current = staged.get(path, original[path])
            if current is None:
                if old or PurePosixPath(edit["path"]).parts[0] not in {"scratch_tests", "target_library", "target"}:
                    raise ToolError("Creating a file requires old='' and a Python library or scratch test path")
                updated = new
            else:
                if not old or current.count(old) != 1:
                    raise ToolError("old must match exactly once; inspect the file before editing")
                updated = current.replace(old, new, 1)
            if len(updated.encode("utf-8")) > self.max_file_bytes:
                raise ToolError("Edited file exceeds the file size limit")
            staged[path] = updated
        if self.validate_syntax:
            for path, content in staged.items():
                relative = path.relative_to(self.root).as_posix()
                if path.suffix != ".py":
                    continue
                try:
                    compile(content, relative, "exec", dont_inherit=True)
                except (SyntaxError, ValueError) as exc:
                    line = getattr(exc, "lineno", None)
                    detail = getattr(exc, "msg", str(exc))
                    raise ToolError(f"Edit transaction was not applied: {relative}:{line}: {detail}. Correct the edit and retry.") from None
        written: list[Path] = []
        try:
            for path, content in staged.items():
                self._path(path.relative_to(self.root).as_posix(), write=True)
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_text(content, encoding="utf-8")
                written.append(path)
        except Exception:
            for path in written:
                if original[path] is None:
                    path.unlink(missing_ok=True)
                else:
                    path.write_text(original[path], encoding="utf-8")
            raise
        record = {"edits": json.loads(json.dumps(edits)), "files": [{
            "path": path.relative_to(self.root).as_posix(),
            "before_sha256": hashlib.sha256(original[path].encode("utf-8")).hexdigest() if original[path] is not None else None,
            "after_sha256": hashlib.sha256(content.encode("utf-8")).hexdigest(),
        } for path, content in staged.items()]}
        self.edit_records.append(record)
        return {"ok": True, **record}
